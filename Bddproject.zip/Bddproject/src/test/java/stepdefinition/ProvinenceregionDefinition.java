package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.SecureTrading;
import utils.Base;

public class ProvinenceregionDefinition extends Base {
	SecureTrading objSecureTrading = new SecureTrading(driver);
	@When("I click the More Categories link for provinence region")
	public void i_click_the_more_categories_link_for_provinence_region() {
		objSecureTrading.clickOnMoreCategories();
	}

	@When("I click the Transportation spoting good section for provinence region")
	public void i_click_the_transportation_spoting_good_section_for_provinence_region() {
		objSecureTrading.clickTransportation();
	}

	@When("I click the Bike for provinence region")
	public void i_click_the_bike_for_provinence_region() {
		objSecureTrading.clickBike();
	}

	@When("I click the Supplier List for provinence region")
	public void i_click_the_supplier_list_for_provinence_region() {
		objSecureTrading.clickSupplierList();
	}

	@When("I Scroll to the provinence region")
	public void i_scroll_to_the_provinence_region() {
		objSecureTrading.scrollProvinence();
	}

	@When("I click the Guangdong")
	public void i_click_the_guangdong() {
		objSecureTrading.clickTheRegion();
	}

	@Then("I verify the Provinence region Guangdong")
	public void i_verify_the_provinence_region_guangdong() {
		objSecureTrading.verifyRegion();
	}

}
