package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.MoreCategories;
import utils.Base;

public class MoreCategoriesDefinition extends Base {

	MoreCategories objMoreCategories = new MoreCategories(driver);

	@When("I Click the More Categories link")
	public void i_click_the_more_categories_link() {
		objMoreCategories.clickOnMoreCategories();
	}

	@When("I Click the Apparel & Light Industry")
	public void i_click_the_apparel_light_industry() {
		objMoreCategories.clickApparelAndLight();
	}

	@Then("I click and Verify the Apparel & Accessories title")
	public void i_click_and_verify_the_apparel_accessories_title() {
		objMoreCategories.clickApparelAndAccessories();
	}

}
