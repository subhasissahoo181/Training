package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.MoreCategories;
import utils.Base;

public class ValidCategoriesDefinition extends Base {
	MoreCategories objMoreCategories = new MoreCategories(driver);

	@When("I click the More Categories link for valid input")
	public void i_click_the_more_categories_link_for_valid_input() {
		objMoreCategories.clickOnMoreCategories();
	}

	@When("I scroll to the HotSearchs with verified")
	public void i_scroll_to_the_hot_searchs_with_verified() {
		objMoreCategories.clickOnHotSearches();
	}

	@When("I click the first button under the HotSearch for valid input")
	public void i_click_the_first_button_under_the_hot_search_for_valid_input() {
		objMoreCategories.clickOnHotSearchesFirstCategoties();
	}

	@When("I click the SecureTrading Button for valid input")
	public void i_click_the_secure_trading_button_for_valid_input() {
		objMoreCategories.clickOnSecuredTradingButtonForInvalidInput();
	}

	@When("I click the MinOrder order input field and pass {int} for valid input")
	public void i_click_the_min_order_order_input_field_and_pass_for_valid_input(Integer int1) {
		objMoreCategories.clickOnMinOrderInputField(int1);
	}

	@When("I click the Ok button for valid input")
	public void i_click_the_ok_button_for_valid_input() {
		objMoreCategories.clickOnMinOrderOkButton();
	}

	@When("I click the MinPrice input fild and pass {int} for valid input")
	public void i_click_the_min_price_input_fild_and_pass_for_valid_input(Integer int1) {
		objMoreCategories.clickOnMinPriceInputField(int1);
	}

	@When("I click the MaxPrice input fild and Pass {int} for valid input")
	public void i_click_the_max_price_input_fild_and_pass_for_valid_input(Integer int1) {
		objMoreCategories.clickOnMaxPriceInputField(int1);
	}

	@When("I click the Ok button for valid PriceInput")
	public void i_click_the_ok_button_for_valid_price_input() {
		objMoreCategories.clickOnPriceOkButton();
	}

	@Then("I verify the product visible withtaking screenshort for valid")
	public void i_verify_the_product_visible_withtaking_screenshort_for_valid() {
		objMoreCategories.clickOnPriceOkButton();
	}

}
