package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.MoreCategories;
import utils.Base;

public class AddProductInBasketDefinition extends Base {
	MoreCategories objMoreCategories = new MoreCategories(driver);
	@When("I click the More Categories link for add product")
	public void i_click_the_more_categories_link_for_add_product() {
		objMoreCategories.clickOnMoreCategories();
	}

	@When("I click chemical & Minerals categories for link")
	public void i_click_chemical_minerals_categories_for_link() {
		objMoreCategories.clickChemicalAndMinerals();
	}

	@When("I click RubberMeterial under Chemical")
	public void i_click_rubber_meterial_under_chemical() {
		objMoreCategories.clickRubberMaterial();
	}

	@When("I click the first product in the card")
	public void i_click_the_first_product_in_the_card() {
		objMoreCategories.clickTheFirstProduct();
	}

	@When("I click the AddInquary basket for the product")
	public void i_click_the_add_inquary_basket_for_the_product() {
		objMoreCategories.addInquaryScroll();
	}

	@When("I click the Inquary button for the product")
	public void i_click_the_inquary_button_for_the_product() {
		objMoreCategories.addInquaryProduct();
	}

	@Then("I verify the product is present in the Inquary box")
	public void i_verify_the_product_is_present_in_the_inquary_box() {
		objMoreCategories.addInquaryCart();
	}

}
