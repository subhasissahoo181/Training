package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.SecureTrading;
import utils.Base;

public class PoloTshirtDefinition extends Base {
	SecureTrading objSecureTrading = new SecureTrading(driver);
	@When("I click the More Categories link for Polo Tshirt")
	public void i_click_the_more_categories_link_for_polo_tshirt() {
		objSecureTrading.clickOnMoreCategories();
	}

	@When("I click the Apparel light for Plot Tshirt")
	public void i_click_the_apparel_light_for_plot_tshirt() {
		objSecureTrading.clickApparelAndLight();
	}

	@When("I click the T-shirt link under the Appereal Assoceries for Polo Tshirt")
	public void i_click_the_t_shirt_link_under_the_appereal_assoceries_for_polo_tshirt() {
		objSecureTrading.clickTshirt();
	}

	@When("I click the Polo Tshirt")
	public void i_click_the_polo_tshirt() {
		objSecureTrading.clickPoloTshirt();
	}

	@When("I click the First Product for Polo Tshirt")
	public void i_click_the_first_product_for_polo_tshirt() {
		objSecureTrading.clickFirstProduct();
	}

	@When("I click the Product details for Polo Tshirt")
	public void i_click_the_product_details_for_polo_tshirt() {
		objSecureTrading.clickProductDetails();
	}

	@Then("I Verify the Model details")
	public void i_verify_the_model_details() {
		objSecureTrading.verifyTheModel();
	}

}
