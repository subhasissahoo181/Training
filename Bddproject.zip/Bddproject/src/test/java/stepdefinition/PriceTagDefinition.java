package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ApparelDetails;
import utils.Base;

public class PriceTagDefinition extends Base{
	ApparelDetails objApparelDetails = new ApparelDetails(driver);
	@When("I click the More Categories link for price tag")
	public void i_click_the_more_categories_link_for_price_tag() {
		objApparelDetails.clickOnMoreCategories();
	}

	@When("I click the Apperail and Light Industry for the price tag")
	public void i_click_the_apperail_and_light_industry_for_the_price_tag() {
		objApparelDetails.apparelLight();
	}

	@When("I click the GiftBox and Bag for price tag")
	public void i_click_the_gift_box_and_bag_for_price_tag() {
		objApparelDetails.clickGiftBoxAndBag();
	}

	@When("I click the First Product for the price tag")
	public void i_click_the_first_product_for_the_price_tag() {
		objApparelDetails.clickFirstProductInGiftBox();
	}

	@Then("I verify the US$ in the price tag")
	public void i_verify_the_us$_in_the_price_tag() {
//		objApparelDetails
	}

}
