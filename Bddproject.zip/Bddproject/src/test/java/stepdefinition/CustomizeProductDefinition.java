package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HavenotFoundProduct;
import utils.Base;

public class CustomizeProductDefinition extends Base {
	HavenotFoundProduct objHavenotFoundProduct = new HavenotFoundProduct(driver);
	@When("I click the More Categories link for custom product")
	public void i_click_the_more_categories_link_for_custom_product() {
		objHavenotFoundProduct.clickOnMoreCategories();
	}

	@When("I scroll to the Have not Found what you want section")
	public void i_scroll_to_the_have_not_found_what_you_want_section() {
		objHavenotFoundProduct.scrollToHavenotFound();
	}

	@When("I click the source now button for customized unique product")
	public void i_click_the_source_now_button_for_customized_unique_product() {
		objHavenotFoundProduct.clickSourceNow();
	}

	@When("I click the input field and pass the value {string}")
	public void i_click_the_input_field_and_pass_the_value(String string) {
		objHavenotFoundProduct.clickInputField(string);
	}

	@When("I click the submit button")
	public void i_click_the_submit_button() {
//		objHavenotFoundProduct
	}

	@Then("I verify the bag is visible or not")
	public void i_verify_the_bag_is_visible_or_not() {
//		objHavenotFoundProduct
	}

}
