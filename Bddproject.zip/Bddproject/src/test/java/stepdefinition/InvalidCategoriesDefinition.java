package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.MoreCategories;
import utils.Base;

public class InvalidCategoriesDefinition extends Base{
	MoreCategories objMoreCategories = new MoreCategories(driver);
	
	@When("I click the More Categories link for Invalid Input")
	public void i_click_the_more_categories_link_for_invalid_input() {
		objMoreCategories.clickOnMoreCategories();
	}

	@When("I scroll to the HotSearchs with verified for Invalid Input")
	public void i_scroll_to_the_hot_searchs_with_verified_for_invalid_input() {
		objMoreCategories.clickOnHotSearchesForInvalidInput();
	}

	@When("I click the first button under the HotSearch  for Invalid Input")
	public void i_click_the_first_button_under_the_hot_search_for_invalid_input() {
		objMoreCategories.clickOnHotSearchesFirstCategotiesForInvalidInput();
	}

	@When("I click the SecureTrading Button for Invalid Input")
	public void i_click_the_secure_trading_button_for_invalid_input() {
		objMoreCategories.clickOnSecuredTradingButtonForInvalidInput();
	}

	@When("I click the MinOrder order input field and pass {int} for Invalid Input")
	public void i_click_the_min_order_order_input_field_and_pass_for_invalid_input(Integer int1) {
		objMoreCategories.clickOnMinOrderInputFieldForInvalidInput(int1);
	}

	@When("I click the Ok button for Invalid Input")
	public void i_click_the_ok_button_for_invalid_input() {
		objMoreCategories.clickOnMinOrderOkButton();
	}

	@When("I click the MinPrice input fild and pass {int} for Invalid Input")
	public void i_click_the_min_price_input_fild_and_pass_for_invalid_input(Integer int1) {
		objMoreCategories.clickOnMinPriceInputFieldForInvalidInput(int1);
	}

	@When("I click the MaxPrice input fild and Pass {int} for Invalid Input")
	public void i_click_the_max_price_input_fild_and_pass_for_invalid_input(Integer int1) {
		objMoreCategories.clickOnMaxPriceInputFieldForInvalidInput(int1);
	}

	@When("I click the Ok button for Invalid PriceInput")
	public void i_click_the_ok_button_for_invalid_price_input() {
		objMoreCategories.clickOnPriceOkButton();
	}

	@Then("I verify the product visible withtaking screenshort for Invalid")
	public void i_verify_the_product_visible_withtaking_screenshort_for_invalid() {
//		objMoreCategories
	}


}
