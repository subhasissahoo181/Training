package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ApparelDetails;
import utils.Base;

public class DiscountProductDefinition extends Base {
	ApparelDetails objApparelDetails = new ApparelDetails(driver);
	@When("I click the More Categories link for verify the fashion accessories")
	public void i_click_the_more_categories_link_for_verify_the_fashion_accessories() {
		objApparelDetails.clickOnMoreCategories();
	}

	@When("I click the Apparel & light for Fashion assoceries verify")
	public void i_click_the_apparel_light_for_fashion_assoceries_verify() {
		objApparelDetails.apparelLight();
	}

	@When("I click the First producr for the verify Fashion accessories")
	public void i_click_the_first_producr_for_the_verify_fashion_accessories() {
		objApparelDetails.clickFashionAccessories();
	}

	@Then("I verify the Fashion Accessories is present or not")
	public void i_verify_the_fashion_accessories_is_present_or_not() {
		objApparelDetails.verifyFashionAccessories();
	}

}
