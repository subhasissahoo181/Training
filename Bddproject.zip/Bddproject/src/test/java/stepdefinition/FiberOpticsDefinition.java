package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Supplier;
import utils.Base;

public class FiberOpticsDefinition extends Base{
	Supplier objSupplier = new Supplier(driver);
	@When("I click the More Categories link for Verify the fiberoptics is avilable or not")
	public void i_click_the_more_categories_link_for_verify_the_fiberoptics_is_avilable_or_not() {
		objSupplier.clickOnMoreCategories();
	}

	@When("I click consumer good and electronic link for verify the fiberoptics is available or not")
	public void i_click_consumer_good_and_electronic_link_for_verify_the_fiberoptics_is_available_or_not() {
		objSupplier.clickOnConsumerGoods();
	}

	@When("I click the fiber optics equipment for the Electrical electronics")
	public void i_click_the_fiber_optics_equipment_for_the_electrical_electronics() {
		objSupplier.clickOnFiberOptics();
	}

	@When("I click the Supplier list button for the Fiber Optics")
	public void i_click_the_supplier_list_button_for_the_fiber_optics() {
		objSupplier.supplierList();
	}

	@Then("I scroll to the Related categories and verify the Fiber optics")
	public void i_scroll_to_the_related_categories_and_verify_the_fiber_optics() {
		objSupplier.scrollVerifyOpticalfiber();
	}

}
