package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.SecureTrading;
import utils.Base;

public class BuyProductWithMoreSeftyDefinition extends Base {
	SecureTrading objSecureTrading = new SecureTrading(driver);
	@When("I click the More Categories link for secure trading")
	public void i_click_the_more_categories_link_for_secure_trading() {
		objSecureTrading.clickOnMoreCategories();
	}

	@When("I click the Apparel Light for secure trading")
	public void i_click_the_apparel_light_for_secure_trading() {
		objSecureTrading.clickApparelAndLight();
	}

	@When("I click the Shoes for secure trading")
	public void i_click_the_shoes_for_secure_trading() {
		objSecureTrading.clickShoesFromApparelLight();
	}

	@When("I click the Start order now link for secure trading")
	public void i_click_the_start_order_now_link_for_secure_trading() {
		objSecureTrading.clickStartOrderInSecureTrading();
	}

	@Then("verify the secure trading and capture screenshort")
	public void verify_the_secure_trading_and_capture_screenshort() {
		objSecureTrading.verifySecureTradingForProduct();
	}

}
