package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HavenotFoundProduct;
import utils.Base;

public class MembershipTypeDefinition extends Base{
	HavenotFoundProduct objHavenotFoundProduct = new HavenotFoundProduct(driver);
	@When("I click the More Categories link for membership type")
	public void i_click_the_more_categories_link_for_membership_type() {
		objHavenotFoundProduct.clickOnMoreCategories();
	}

	@When("I click the Chemical and Mineral for membership type")
	public void i_click_the_chemical_and_mineral_for_membership_type() {
		objHavenotFoundProduct.clickChemicalAndMinerals();
	}

	@When("I click the steel product for membership type")
	public void i_click_the_steel_product_for_membership_type() {
		objHavenotFoundProduct.clickSteelProduct();
	}

	@When("I scroll to the Member type")
	public void i_scroll_to_the_member_type() {
		objHavenotFoundProduct.scrollToMemberType();
	}

	@When("I click the diamond member")
	public void i_click_the_diamond_member() {
		objHavenotFoundProduct.clickDiamondMember();
	}

	@When("I click the first product for member type")
	public void i_click_the_first_product_for_member_type() {
//		objHavenotFoundProduct
	}

	@Then("I verify the Diamond membership is presenet or not with capture screenshort")
	public void i_verify_the_diamond_membership_is_presenet_or_not_with_capture_screenshort() {
//		objHavenotFoundProduct
	}

}
