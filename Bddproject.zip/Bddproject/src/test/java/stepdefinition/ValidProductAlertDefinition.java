package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HavenotFoundProduct;
import utils.Base;

public class ValidProductAlertDefinition extends Base {
	HavenotFoundProduct objHavenotFoundProduct = new HavenotFoundProduct(driver);
	@When("I click the More Categories link for Product Alert")
	public void i_click_the_more_categories_link_for_product_alert() {
		objHavenotFoundProduct.clickOnMoreCategories();
	}

	@When("I scroll to Have not found for product alert")
	public void i_scroll_to_have_not_found_for_product_alert() {
		objHavenotFoundProduct.scrollToHavenotFound();
	}

	@When("I click the subscribe button for product alert")
	public void i_click_the_subscribe_button_for_product_alert() {
		objHavenotFoundProduct.clickOnSubscribeProduct();
	}

	@When("I click the Search bar field and pass {string} for product alert")
	public void i_click_the_search_bar_field_and_pass_for_product_alert(String string) {
		objHavenotFoundProduct.clickOnInputField(string);
	}

	@When("I click the confirm button for product alert")
	public void i_click_the_confirm_button_for_product_alert() {
		objHavenotFoundProduct.clickOnConfirmButton();
	}

	@Then("I verify the computer product")
	public void i_verify_the_computer_product() {
//		objHavenotFoundProduct
	}

}
