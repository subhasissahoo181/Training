package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.SecureTrading;
import utils.Base;

public class AgeRangeDefinition extends Base{
	SecureTrading objSecureTrading = new SecureTrading(driver);
	@When("I click the More Categories link for Age range")
	public void i_click_the_more_categories_link_for_age_range() {
		objSecureTrading.clickOnMoreCategories();
	}

	@When("I click the Apparel light for Age range")
	public void i_click_the_apparel_light_for_age_range() {
		objSecureTrading.clickApparelAndLight();
	}

	@When("I click children apparel for age range")
	public void i_click_children_apparel_for_age_range() {
		objSecureTrading.clickChildrenApparelFromApparel();
	}

	@When("I scroll to the Age for filter age range")
	public void i_scroll_to_the_age_for_filter_age_range() {
		objSecureTrading.scrollToTheAge();
	}

	@When("I click the age range two year to six year")
	public void i_click_the_age_range_two_year_to_six_year() {
		objSecureTrading.clickTheAgeRanged();
	}

	@Then("I verify the age range capture screenshort")
	public void i_verify_the_age_range_capture_screenshort() {
		objSecureTrading.verifyTheAgeRangeCapdtureScreenShort();
	}

}
