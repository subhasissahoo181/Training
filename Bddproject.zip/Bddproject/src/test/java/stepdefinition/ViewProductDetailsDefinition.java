package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.ApparelDetails;
import utils.Base;

public class ViewProductDetailsDefinition extends Base{
	ApparelDetails objApparelDetails = new ApparelDetails(driver);
	@When("I click the More Categories link for see the shoes details")
	public void i_click_the_more_categories_link_for_see_the_shoes_details() {
		objApparelDetails.clickOnMoreCategories();
	}

	@When("I click the Apperail and Light for Shoes details")
	public void i_click_the_apperail_and_light_for_shoes_details() {
		objApparelDetails.apparelLight();
	}

	@When("I click Shoes details under the Apparel accessories")
	public void i_click_shoes_details_under_the_apparel_accessories() {
		objApparelDetails.clicktheShoes();
	}

	@When("I click the first product for Shoes")
	public void i_click_the_first_product_for_shoes() {
		objApparelDetails.clickFirstProduct();
	}

	@When("I click the Product details")
	public void i_click_the_product_details() {
		objApparelDetails.productionDetails();
	}

	@Then("I verify the Basic Info")
	public void i_verify_the_basic_info() {
		objApparelDetails.productionBasicDetails();
	}

}
