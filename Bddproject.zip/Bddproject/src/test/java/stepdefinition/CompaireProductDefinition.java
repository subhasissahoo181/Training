package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HavenotFoundProduct;
import utils.Base;

public class CompaireProductDefinition extends Base {
	HavenotFoundProduct objHavenotFoundProduct = new HavenotFoundProduct(driver);
	@When("I click the More Categories link for compaire two product")
	public void i_click_the_more_categories_link_for_compaire_two_product() {
		objHavenotFoundProduct.clickOnMoreCategories();
	}

	@When("I click the Home and security for compaire product")
	public void i_click_the_home_and_security_for_compaire_product() {
		objHavenotFoundProduct.clickHomeAndSecurity();
	}

	@When("I click the sofa for compaire product")
	public void i_click_the_sofa_for_compaire_product() {
		objHavenotFoundProduct.clickOnSofa();
	}

	@When("I click the first product for compaire product")
	public void i_click_the_first_product_for_compaire_product() {
		objHavenotFoundProduct.clickFirstProduct();
	}

	@When("I click add inquary button for compaire product")
	public void i_click_add_inquary_button_for_compaire_product() {
		objHavenotFoundProduct.scrollFirstProductAddInquary();
	}

	@When("I click the first product from the find similar card")
	public void i_click_the_first_product_from_the_find_similar_card() {
		objHavenotFoundProduct.clickFirstProductInFindsimilar();
	}

	@When("I click the Inquary basket for compaire the product")
	public void i_click_the_inquary_basket_for_compaire_the_product() {
		objHavenotFoundProduct.scrollFirstProductAddInquary();
	}

	@When("I click the select all link for compaire product")
	public void i_click_the_select_all_link_for_compaire_product() {
//		objHavenotFoundProduct
	}

	@When("I click the compaire button to compaire")
	public void i_click_the_compaire_button_to_compaire() {
//		objHavenotFoundProduct
	}

	@Then("I verify compaire product details and capturescreenshort")
	public void i_verify_compaire_product_details_and_capturescreenshort() {
//		objHavenotFoundProduct
	}

}
