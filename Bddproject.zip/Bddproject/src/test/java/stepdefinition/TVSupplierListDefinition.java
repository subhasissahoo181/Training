package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Supplier;
import utils.Base;

public class TVSupplierListDefinition extends Base {
	Supplier objSupplier = new Supplier(driver);
	@When("I click the More Categories link for Verify TV parts supplier list")
	public void i_click_the_more_categories_link_for_verify_tv_parts_supplier_list() {
		objSupplier.clickOnMoreCategories();
	}

	@When("I click the Consumer Goods Electronic for TV parts")
	public void i_click_the_consumer_goods_electronic_for_tv_parts() {
		objSupplier.clickOnConsumerGoods();
	}

	@When("I click the TV parts link under consumer electronics")
	public void i_click_the_tv_parts_link_under_consumer_electronics() {
		objSupplier.clickOnTvParts();
	}

	@When("I click the supplier list button for TV parts")
	public void i_click_the_supplier_list_button_for_tv_parts() {
		objSupplier.supplierList();
	}

	@Then("I verify the TV Parts supplier list button")
	public void i_verify_the_tv_parts_supplier_list_button() {
		objSupplier.verifyTVPartssupplierList();
	}

}
