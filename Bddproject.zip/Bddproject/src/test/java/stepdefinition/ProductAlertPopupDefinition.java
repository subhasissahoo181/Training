package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HavenotFoundProduct;
import utils.Base;

public class ProductAlertPopupDefinition extends Base {
	HavenotFoundProduct objHavenotFoundProduct = new HavenotFoundProduct(driver);
	@When("I click the More Categories link for valid product alert")
	public void i_click_the_more_categories_link_for_valid_product_alert() {
		objHavenotFoundProduct.clickOnMoreCategories();
	}

	@When("I click the Have not found for valid product alert")
	public void i_click_the_have_not_found_for_valid_product_alert() {
		objHavenotFoundProduct.scrollToHavenotFound();
	}

	@When("I click the subscribe button for valid product alert")
	public void i_click_the_subscribe_button_for_valid_product_alert() {
		objHavenotFoundProduct.clickOnSubscribeProduct();
	}
	@When("I click the search bar and pass {string} for alert")
	public void i_click_the_search_bar_and_pass_for_alert(String string) {
		objHavenotFoundProduct.clickOnInputField(string);
	}

	@When("I click the confirm button for valid product alert")
	public void i_click_the_confirm_button_for_valid_product_alert() {
		objHavenotFoundProduct.clickOnConfirmButton();
	}

	@When("I click the subscribe button")
	public void i_click_the_subscribe_button() {
//		objHavenotFoundProduct
	}

	@Then("I verify signin title popup box")
	public void i_verify_signin_title_popup_box() {
		objHavenotFoundProduct.clickOnSubscribeButtonToSubscribe();
	}

}
