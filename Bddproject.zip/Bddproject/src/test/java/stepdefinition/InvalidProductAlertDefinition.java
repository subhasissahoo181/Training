package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HavenotFoundProduct;
import utils.Base;

public class InvalidProductAlertDefinition extends Base {
	HavenotFoundProduct objHavenotFoundProduct = new HavenotFoundProduct(driver);
	@When("I click the More Categories link for invalid product alert")
	public void i_click_the_more_categories_link_for_invalid_product_alert() {
		objHavenotFoundProduct.clickOnMoreCategories();
	}

	@When("I click the Have not found for invalid product alert")
	public void i_click_the_have_not_found_for_invalid_product_alert() {
		objHavenotFoundProduct.scrollToHavenotFound();
	}

	@When("I click the subscribe button for invalid product alert")
	public void i_click_the_subscribe_button_for_invalid_product_alert() {
		objHavenotFoundProduct.clickOnSubscribeProduct();
	}

	@When("I click the search bar and pass {string}")
	public void i_click_the_search_bar_and_pass(String string) {
		objHavenotFoundProduct.clickOnInputFieldPassInvalidInput(string);
	}

	@When("I click the confirm button for invalid product alsert")
	public void i_click_the_confirm_button_for_invalid_product_alsert() {
		objHavenotFoundProduct.clickOnConfirmButtonWithInvalidInput();
	}

	@Then("I verify the error message for invalid input")
	public void i_verify_the_error_message_for_invalid_input() {
//		objHavenotFoundProduct
	}

}
