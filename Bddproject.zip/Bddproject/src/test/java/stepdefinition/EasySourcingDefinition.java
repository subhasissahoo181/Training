package stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.SecureTrading;
import utils.Base;

public class EasySourcingDefinition extends Base {
	SecureTrading objSecureTrading = new SecureTrading(driver);
	@When("I scroll to Easy sourcing for T-Shirt")
	public void i_scroll_to_easy_sourcing_for_t_shirt() {
		objSecureTrading.scrollToEasySourcing();
	}

	@When("I click the product keyword and enter value {string} in the input field")
	public void i_click_the_product_keyword_and_enter_value_in_the_input_field(String string) {
		objSecureTrading.clickProductNameKeywordInputField(string);
	}

	@When("I click the post request button")
	public void i_click_the_post_request_button() {
		objSecureTrading.clickPostYourRequestButton();
	}

	@Then("I verify the T-Shirt in the input field of post request")
	public void i_verify_the_t_shirt_in_the_input_field_of_post_request() {
		objSecureTrading.VerifyTheInputField();
	}

}
