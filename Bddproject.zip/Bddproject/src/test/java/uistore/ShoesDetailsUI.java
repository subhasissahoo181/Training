package uistore;

import org.openqa.selenium.By;

public class ShoesDetailsUI {
	// TestCase-1	
		public static By moreCategories = By.xpath("//span[@class='fl cate-name']");
		public static By apparelAndLight = By.xpath("(//a[@class='J-tab-anchor tab-anchor'])[4]");
		public static By shoes = By.xpath("(//a[@class='item-anchor'])[70]");
		public static By firstProduct = By.xpath("(//div[@class='img-thumb-inner']/img)[2]");
		public static By productDetails = By.xpath("//span[text()='Product Details']");
		public static By basicInfo = By.xpath("(//h2[@class='sr-txt-h2'])[1]");
}
