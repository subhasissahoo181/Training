package uistore;

import org.openqa.selenium.By;

public class ChemicalMineralsUI {
	public static By moreCategories = By.xpath("//span[@class='fl cate-name']");
	public static By chemicalAndMinerals = By.xpath("(//a[@class='J-tab-anchor tab-anchor'])[6]");
	public static By verifyChemical = By.xpath("(//h2[@class='primary-title'])[6]");
	public static By rubberMaterials = By.xpath("(//div[@class='sec-classify']/ul/li/a)[106]");
	public static By verifyRubberMaterial = By.xpath("//h1[text()=' Rubber Materials ']");
	public static By firstProduct = By.xpath("(//div[@class='img-thumb-inner']/img)[2]");
//	public static By firstProduct = By.xpath("(//h2[@class='product-name'])[1]");
	public static By similarProduct = By.xpath("//div[text()='Find Similar Products']");
	public static By addInquiry = By.xpath("//a[@title='Add Inquiry Basket to Compare']");
	public static By inquiryBasket = By.xpath("(//div[@id='in-basket']/div/span)[1]");
	public static By product = By.xpath("(//ul[@class='in-basket-tab']/li)[1]");
	

}

