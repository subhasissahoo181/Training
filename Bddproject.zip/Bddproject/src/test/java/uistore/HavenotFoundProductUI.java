package uistore;

import org.openqa.selenium.By;

public class HavenotFoundProductUI {
	// Testcase-11
	public static By moreCategories = By.xpath("//span[@class='fl cate-name']");
	public static By chinaProductsDirectory = By.xpath("//h1[text()='China Products Directory']");
	public static By haveNotFound = By.xpath("(//div[@class='content-title'])[2]");
	public static By sourcingRequest = By.xpath("//a[@href='https://purchase.made-in-china.com/trade-service/quotation-request.html?pv_id=1id67n3tu8a7&faw_id=null']");
	public static By verifySourcing = By.xpath("//h2[@class='title']");
	public static By productName = By.xpath("//input[@id='subjectId']");
	public static By categories = By.xpath("//select[@id='category']");
	//Testcase-14
	public static By subscribeNow = By.xpath("//a[@href='https://www.made-in-china.com/product-alert/']");
	public static By subscribeProdAlert = By.xpath("(//h3[@class='title'])[1]");
	public static By inputField = By.xpath("//input[@name='keyword']");
	public static By confirm = By.xpath("//button[@type='button']");
	public static By product = By.xpath("(//span[text()='Computer Products >> Computer Products'])[1]");
	public static By invalidProduct = By.xpath("//div[@class='alert-scene scene-2']/p");
//	Testcase-16
	public static By clickSubscribebutton = By.xpath("(//button[@type='submit'])[2]");
	public static By verifySignIn = By.xpath("//span[text()='Sign in with']");
	

}
