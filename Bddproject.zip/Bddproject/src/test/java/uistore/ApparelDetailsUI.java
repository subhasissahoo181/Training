package uistore;

import org.openqa.selenium.By;

public class ApparelDetailsUI {
	// TestCase-1	
		public static By moreCategories = By.xpath("//span[@class='fl cate-name']");
		public static By apparelAndLight = By.xpath("(//a[@class='J-tab-anchor tab-anchor'])[4]");
		public static By verifyApparelAndLight = By.xpath("//h2[text()='Apparel & Light Industry']");
		public static By shoes = By.xpath("(//a[@class='item-anchor'])[70]");
		public static By verifyShoes = By.xpath("//h1[text()=' Shoes ']");
		public static By firstProduct = By.xpath("(//div[@class='img-thumb-inner']/img)[2]");
		public static By productDetails = By.xpath("//span[text()='Product Details']");
		public static By basicInfo = By.xpath("(//h2[@class='sr-txt-h2'])[1]");
		public static By fashionAccessories = By.xpath("(//a[@class='item-anchor'])[73]");
		public static By verifyFashionAccessories = By.xpath("//h1[text()=' Fashion Accessories ']");
		public static By contactSupplier = By.xpath("(//a[@class='btns button-link-contact'])[1]");
		public static By sendInquary = By.xpath("//span[@class='m-channel-name-content']");
		public static By giftAndBag = By.xpath("(//a[@class='item-anchor'])[78]");
		public static By verifyGiftAndBag = By.xpath("//h1[@class='product_word']");
		
		
		
		
		public static By usDolar = By.xpath("//span[@class='only-one-priceNum-td-left']");
}
