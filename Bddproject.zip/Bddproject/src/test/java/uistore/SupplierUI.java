package uistore;

import org.openqa.selenium.By;

public class SupplierUI {
	public static By moreCategories = By.xpath("//span[@class='fl cate-name']");
	public static By chinaProductsDirectory = By.xpath("//h1[text()='China Products Directory']");
	public static By consumerGoods = By.xpath("(//a[@class='J-tab-anchor tab-anchor'])[5]");
	public static By verifyConsumerGoods = By.xpath("(//h2[@class='primary-title'])[5]");
	public static By tvParts = By.xpath("//a[@href='//www.made-in-china.com/Consumer-Electronics-Catalog/TV-Parts.html']");
	public static By verifyTvParts = By.xpath("//h1[@class='product_word']");
	public static By supplierList = By.xpath("//a[@href='//www.made-in-china.com/manufacturers-directory/item3/TV-Parts-1.html']");
	public static By verifyTvPartsSupplierList = By.xpath("(//span[@itemprop='name'])[4]");
	public static By fiberOptics = By.xpath("(//a[@class='item-anchor'])[97]");
	public static By verifyFiberOptics = By.xpath("//h1[@class='product_word']");
	public static By relatedCategories = By.xpath("//h3[text()='Related Categories:	']");
	public static By verifyOpticalFiber = By.xpath("(//a[text()='Optical Fiber'])[2]");

}
