package utils;

import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
// import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.Set;

public class DriverHelper {
	private WebDriver driver;

	public DriverHelper(WebDriver driver) {
		this.driver = driver;
	}

	/*------------Wait for element to visible is use for explicit wait---------*/
	public void waitForElementToBeVisible(By locator, int timeoutInSeconds) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds))
					.until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	/*---------Click the element------------*/
	public void clickOnElement(By locator) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);
			webElement.click();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	/*---------Clear the input field -----------*/
	public void clearElement(By locator) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);
			webElement.clear();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	

	/*-----------Send keys for fetch string data and pass in the input field------------*/
	public void sendKeys(By locator, String data) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);
			webElement.sendKeys(data);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*---------Send keys for fetch Integer data and pass in the input field ------------*/
	public void sendKeysInteger(By locator, Integer data) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);

			// Convert the integer to a string
			String dataAsString = data.toString();

			// Use the string value with sendKeys
			webElement.sendKeys(dataAsString);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*---------Soft assertion for the equal/exact string present-----------*/
	public void softAsserting(String actual, String expected) {
		try {
			SoftAssertions sassert = new SoftAssertions();
			sassert.assertThat(actual).isEqualTo(expected);
		} catch (Exception e) {
			LoggerGeneretor.fatal("Give a Valid Locator For Proper Assertion");
		}
	}
	/*---------Soft assertion for the substring present in the string -----------*/
	public void softAssertContaing(String actual, String expected) {
		try {
			SoftAssertions sassert = new SoftAssertions();
			sassert.assertThat(actual).contains(expected);
		} catch (Exception e) {
			LoggerGeneretor.fatal("Give a Valid Locator For Containing Assertion");

		}
	}
	/* ---------- find the text inside the locater------------*/
	public String getText(By locator) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);
			return webElement.getText();
		} catch (Exception e) {

			e.printStackTrace();
			return null;
		}
	}
	/*------------javascript click element --------------------*/
	public void jsClick(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", element);
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	/* ---------- scroll to the element --------------*/
	public void javascriptScroll(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", element);
			js.executeScript("arguments[0].scrollIntoView();", element);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	/*----------Pass controll to one tab to another------------*/
	public void switchToNewWindow() {
		try {
			Set<String> windowHandles = driver.getWindowHandles();
			for (String windowHandle : windowHandles) {
				if (!windowHandle.isEmpty()) {
					driver.switchTo().window(windowHandle);
				} else {
					throw new Exception("New window could not be retrieved");
				}
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
	/* ------------Enter action perform Keyboard action---------------*/
	public void enterAction(By locator) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);
			webElement.sendKeys(Keys.ENTER);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/* ----------------Hover the elements------------*/
	public void hoverOverElement(By locator) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);
			Actions actions = new Actions(driver);
			actions.moveToElement(webElement).perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*-----------------Double click the elements -------------*/
	public void doubleClickOnElement(By locator) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);
			Actions actions = new Actions(driver);
			actions.doubleClick(webElement).perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*-------------Switch to parent window------------*/
	public void switchToParentWindow(String parent){
        try {
            driver.switchTo().window(parent);    
        } catch (Exception e) {
             e.getMessage();
        }
    }
	/*----------select one option by visible text-----------*/
	public void selectOptions(By locator, String visibleText) {
	    try {
	        Select select = new Select(driver.findElement(locator));
	        select.selectByVisibleText(visibleText);
	    } catch (Exception e) {
	        e.getMessage();
	    }
	}
	/*-----------------Alert -------------*/
	public void alertHandle(By locator) {
		try {
			WebElement webElement = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].style.border='3px solid green'", webElement);
			Alert alert = driver.switchTo().alert();
		     alert.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 

	/*--------------Puse the action by using Thread.sleep------------*/
	public void puse(int time) {
		try {
			Thread.sleep(time*1000);
		}catch(Exception e) {
			e.getMessage();
		}
	}

}