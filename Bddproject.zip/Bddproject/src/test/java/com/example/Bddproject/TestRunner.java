package com.example.Bddproject;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import java.io.IOException;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import org.junit.AfterClass;

@RunWith(Cucumber.class)
@CucumberOptions(features = "features", glue = {"stepdefinition"}, tags = "@MoreCategories")
public class TestRunner {
	@AfterClass
	public static void sendingMail() throws AddressException, IOException, MessagingException {
		Mailing sendMail = new Mailing();
		try {
			sendMail.mail();
			System.out.println("Report has been sent");
		} catch (IOException | MessagingException e) {
			e.printStackTrace();
		}
	}
   
}