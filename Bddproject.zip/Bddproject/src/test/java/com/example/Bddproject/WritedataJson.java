package com.example.Bddproject;

public class WritedataJson {

}
