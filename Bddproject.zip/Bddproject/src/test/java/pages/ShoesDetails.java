package pages;

public class ShoesDetails {
	

}
