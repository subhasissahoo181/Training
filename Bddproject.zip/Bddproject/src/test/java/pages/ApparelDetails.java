package pages;

import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
//import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import stepdefinition.Hooks;
import uistore.ChemicalMineralsUI;
import uistore.MoreCategoriesUI;
import uistore.ApparelDetailsUI;
import utils.LoggerGeneretor;
import utils.ReporterMaker;
import utils.CaptureScreenshot;

import utils.DriverHelper;

public class ApparelDetails {
	WebDriver driver;
	DriverHelper helper;

	public ApparelDetails(WebDriver driver) {
		this.driver = driver;
		helper = new DriverHelper(driver);
	}

/*------------------------TestCase-5-------------------------------*/
	/*
	 * Method Name:- isShoesDetails() Author Name:- SubhasisSahoo(10820896) Short
	 * Description Of Method:- Open the application through the website URL and
	 * Verify that the user can browse various product categories. Return Type:-
	 * Void Parameter LIst:- NotApplicable
	 */
	public void moreShoesDetails() {
		clickOnMoreCategories();
		apparelLight();
		clicktheShoes();
		clickFirstProduct();
		productionDetails();

	}

	public void clickOnMoreCategories() {
		// Click the More Categories link
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.moreCategories, 20);
			helper.clickOnElement(MoreCategoriesUI.moreCategories);
			Hooks.test.assignAuthor("Chandan");
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.chinaProductsDirectory, 20);
				String actualData = helper.getText(MoreCategoriesUI.chinaProductsDirectory);
				String expectedData = "China Products Directory";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	public void apparelLight() {

		// Click the Apparel and light industry
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.apparelAndLight, 20);
			helper.clickOnElement(ApparelDetailsUI.apparelAndLight);

			// test.pass("sample", ReporterMaker.createScreenCaptureFromBase64String(
			// CaptureScreenshot.captureScreenshotAsBase64("passSnap")).build());
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.verifyApparelAndLight, 20);
				String actualData = helper.getText(ApparelDetailsUI.verifyApparelAndLight);
				String expectedData = "Apparel & Light Industry";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the Apparel & Light Industry is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the Apparel & Light Industry is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the Apparel & Light Industry title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the Apparel & Light Industry title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}
		} catch (Exception e) {
			LoggerGeneretor.error("Verify the Apparel & Light Industry Fail");
			Hooks.test.log(Status.FAIL, "Verify the Apparel & Light Industry Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ApparelLighytIndustry");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ApparelLightIndustry");
		}
	}

	public void clicktheShoes() {
		// Click the shoes
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.shoes, 20);
			helper.clickOnElement(ApparelDetailsUI.shoes);
			helper.switchToNewWindow();

			// Verify the shoes title is present.
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.verifyShoes, 20);
				String actualData = helper.getText(ApparelDetailsUI.verifyShoes);
				String expectedData = " Shoes ";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the Shoes is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the Shoes is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the Shoes title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the Shoes title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("Shoes");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "Shoes");
			}
		} catch (Exception e) {
			LoggerGeneretor.error("Verify the China Products Directory Fail");
			Hooks.test.log(Status.FAIL, "Verify the China Products Directory Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("VerifyShoes");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyShoes");
		}

	}

	public void clickFirstProduct() {
		// Click the First Product Under card.
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.firstProduct, 30);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,400)");
			helper.clickOnElement(ApparelDetailsUI.firstProduct);
			helper.switchToNewWindow();
			// Verify the shoes title is present.
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.verifyShoes, 20);
				String actualData = helper.getText(ApparelDetailsUI.verifyShoes);
				String expectedData = " Shoes ";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the Shoes is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the Shoes is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the Shoes title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the Shoes title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("Shoes");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "Shoes");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on First Product Fail");
			Hooks.test.log(Status.FAIL, "Click on First Product link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstProduct");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "FirstProduct");
		}
	}

	public void productionDetails() {
		// Click the Product Deatils
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.productDetails, 20);
			helper.clickOnElement(ApparelDetailsUI.productDetails);
			// Verify the Basic Info
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.basicInfo, 20);
				String actualData = helper.getText(ApparelDetailsUI.basicInfo);
				String expectedData = "Basic Info.";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify " + actualData + " title Pass");
				Hooks.test.log(Status.PASS, "Verify " + actualData + " title Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify Apparel & Accessories title Fail");
				Hooks.test.log(Status.FAIL, "Verify Apparel & Accessories title Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifiedApparelAndAccessories");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifiedApparelAndAccessories");
			}
			CaptureScreenshot.captureScreenShot("Apparel Verified");
		} catch (Exception e) {
			LoggerGeneretor.error("Verify the China Products Directory Fail");
			Hooks.test.log(Status.FAIL, "Verify the China Products Directory Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
		}

	}
	public void productionBasicDetails() {
		
		// Verify the Basic Info
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.basicInfo, 20);
			String actualData = helper.getText(ApparelDetailsUI.basicInfo);
			String expectedData = "Basic Info.";
			helper.softAsserting(actualData, expectedData);
			System.out.println(actualData);
			LoggerGeneretor.info("Verify " + actualData + " title Pass");
			Hooks.test.log(Status.PASS, "Verify " + actualData + " title Pass");
		} catch (Exception e) {
			LoggerGeneretor.error("Verify Apparel & Accessories title Fail");
			Hooks.test.log(Status.FAIL, "Verify Apparel & Accessories title Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("VerifiedApparelAndAccessories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifiedApparelAndAccessories");
		}
		CaptureScreenshot.captureScreenShot("Apparel Verified");
	

}

	/*---------------------------------------Test case-6 ---------------------------------*/

	public void fashionAccessories() {
		clickOnMoreCategories();
		apparelLight();
		clickFashionAccessories();

	}

	/*
	 * Method Name:- isFashionDetails() Author Name:- SubhasisSahoo(10820896) Short
	 * Description Of Method:- Validate that the user can buy a product with a
	 * valuable price or Discounted price. Return Type:- Void Parameter LIst:-
	 * NotApplicable
	 */

	public void clickFashionAccessories() {
		// Click the More Categories link
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.fashionAccessories, 20);
			helper.clickOnElement(ApparelDetailsUI.fashionAccessories);
			helper.switchToNewWindow();
			// Verify the Basic Info
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.verifyFashionAccessories, 20);
				String actualData = helper.getText(ApparelDetailsUI.verifyFashionAccessories);
				String expectedData = " Fashion Accessories ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify " + actualData + " title Pass");
				Hooks.test.log(Status.PASS, "Verify " + actualData + " title Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify Apparel & Accessories title Fail");
				Hooks.test.log(Status.FAIL, "Verify Apparel & Accessories title Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifiedApparelAndAccessories");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifiedApparelAndAccessories");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}
	public void verifyFashionAccessories() {
		
			// Verify the Basic Info
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.verifyFashionAccessories, 20);
				String actualData = helper.getText(ApparelDetailsUI.verifyFashionAccessories);
				String expectedData = " Fashion Accessories ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify " + actualData + " title Pass");
				Hooks.test.log(Status.PASS, "Verify " + actualData + " title Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify Apparel & Accessories title Fail");
				Hooks.test.log(Status.FAIL, "Verify Apparel & Accessories title Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifiedApparelAndAccessories");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifiedApparelAndAccessories");
			}

		

	}

	/*---------------------------------------Test case-7 ---------------------------------*/

	public void fashionAccessoriesContactSupport() {
		clickOnMoreCategories();
		apparelLight();
		clickFashionAccessories();
		clickFirstProduct();
		clickFashionAccessoriesContactSupport();

	}

	/*
	 * Method Name:- isFashionDetails() Author Name:- SubhasisSahoo(10820896) Short
	 * Description Of Method:- Validate that the user can buy a product with a
	 * valuable price or Discounted price. Return Type:- Void Parameter LIst:-
	 * NotApplicable
	 */

	public void clickFashionAccessoriesContactSupport() {
		// Click the contactSupplier link
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.contactSupplier, 20);
			helper.clickOnElement(ApparelDetailsUI.contactSupplier);
			helper.switchToNewWindow();
			// Verify the Basic Info
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.sendInquary, 20);
				String actualData = helper.getText(ApparelDetailsUI.sendInquary);
				String expectedData = "    Send Inquiry";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify " + actualData + " title Pass");
				Hooks.test.log(Status.PASS, "Verify " + actualData + " title Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify Apparel & Accessories title Fail");
				Hooks.test.log(Status.FAIL, "Verify Apparel & Accessories title Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifiedApparelAndAccessories");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifiedApparelAndAccessories");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}
	
	
	/*---------------------------------------Test case-8 ---------------------------------*/

	public void verifyUS$inProductPage() {
		clickOnMoreCategories();
		apparelLight();
		clickGiftBoxAndBag();
		clickFirstProductInGiftBox();
		
		

	}

	/*
	 * Method Name:- isFashionDetails() Author Name:- SubhasisSahoo(10820896) Short
	 * Description Of Method:- Validate that the user can buy a product with a
	 * valuable price or Discounted price. Return Type:- Void Parameter LIst:-
	 * NotApplicable
	 */

	public void clickGiftBoxAndBag() {
		// Click the clickGiftBoxAndBag link
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.giftAndBag, 20);
			helper.clickOnElement(ApparelDetailsUI.giftAndBag);
			helper.switchToNewWindow();
			Hooks.test.assignAuthor("Subhasis", "Chandan");
			// Verify the Basic Info
			 
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.verifyGiftAndBag, 20);
				String actualData = helper.getText(ApparelDetailsUI.verifyGiftAndBag);
				String expectedData = " Gift Box & Bag ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify " + actualData + " title Pass");
				Hooks.test.log(Status.PASS, "Verify " + actualData + " title Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify Gift Box & Bag title Pass");
//				System.out.println(actualData);
				Hooks.test.log(Status.FAIL, "Verify Apparel & Accessories title Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifiedApparelAndAccessories");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifiedApparelAndAccessories");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}
	public void clickFirstProductInGiftBox() {
		// Click the First Product Under card.
		try {
			helper.waitForElementToBeVisible(ApparelDetailsUI.firstProduct, 30);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,400)");
			helper.clickOnElement(ApparelDetailsUI.firstProduct);
			helper.switchToNewWindow();
			// Verify the shoes title is present.
			try {
				helper.waitForElementToBeVisible(ApparelDetailsUI.usDolar, 20);
				String actualData = helper.getText(ApparelDetailsUI.usDolar);
				String expectedData = "US$";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the Gift is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the Gift is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the Gift title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the Gift title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("Shoes");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "Gift");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on First Product Fail");
			Hooks.test.log(Status.FAIL, "Click on First Product link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstProduct");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "FirstProduct");
		}
	}
	
	


}
