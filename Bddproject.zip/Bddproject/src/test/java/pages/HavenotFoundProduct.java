package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import stepdefinition.Hooks;
import uistore.ChemicalMineralsUI;
import uistore.HavenotFoundProductUI;
import uistore.MoreCategoriesUI;
import uistore.HavenotFoundProductUI;
import utils.CaptureScreenshot;
import utils.DriverHelper;
import utils.LoggerGeneretor;
//import utils.ReadFromExcel;
import utils.ReporterMaker;

public class HavenotFoundProduct {
	WebDriver driver;
	DriverHelper helper;

	public HavenotFoundProduct(WebDriver driver) {
		this.driver = driver;
		helper = new DriverHelper(driver);
	}

	/*---------------Testcase-11---------------*/

//	public void souricingRequest() {
//		clickOnMoreCategories();
//		scrollToHavenotFound();
//		clickSourceNow();
//		clickInputField();
//
//	}

	public void clickOnMoreCategories() {
		// Click the More Categories link
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.moreCategories, 20);
			helper.clickOnElement(HavenotFoundProductUI.moreCategories);
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.chinaProductsDirectory, 20);
				String actualData = helper.getText(HavenotFoundProductUI.chinaProductsDirectory);
				String expectedData = "China Products Directory";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	public void scrollToHavenotFound() {
		// Click the Chemicals & Minerals link
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.haveNotFound, 20);
			helper.javascriptScroll(HavenotFoundProductUI.haveNotFound);
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.haveNotFound, 20);
				String actualData = helper.getText(HavenotFoundProductUI.haveNotFound);
				String expectedData = "Haven’t found what you want?";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the Source Now Button
	public void clickSourceNow() {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.sourcingRequest, 20);
			helper.clickOnElement(HavenotFoundProductUI.sourcingRequest);
			helper.switchToNewWindow();
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.verifySourcing, 20);
				String actualData = helper.getText(HavenotFoundProductUI.verifySourcing);
				String expectedData = "Tell suppliers what you need";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the input field
	public void clickInputField(String stringData) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.productName, 20);
			helper.clickOnElement(HavenotFoundProductUI.productName);			
			helper.sendKeys(HavenotFoundProductUI.productName, stringData);
			System.out.println(stringData);
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.categories, 20);
				String actualData = helper.getText(HavenotFoundProductUI.categories);
				String expectedData = "Packaging & Printing»Package & Conveyance»Packaging Bags";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}
	/*---------------Testcase-12---------------*/
	public void diamondMembers() {
		clickOnMoreCategories();
		clickChemicalAndMinerals();
		clickSteelProduct();
		scrollToMemberType();
		clickDiamondMember();

	}
	public void clickChemicalAndMinerals() {
		// Click the Chemicals & Minerals link
		try {
			helper.waitForElementToBeVisible(ChemicalMineralsUI.chemicalAndMinerals, 20);
			helper.clickOnElement(ChemicalMineralsUI.chemicalAndMinerals);
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(ChemicalMineralsUI.verifyChemical, 20);
				String actualData = helper.getText(ChemicalMineralsUI.verifyChemical);
				String expectedData = "Chemicals & Minerals";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the steel product
	public void clickSteelProduct() {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.steelProduct, 20);
			helper.clickOnElement(MoreCategoriesUI.steelProduct);
			helper.switchToNewWindow();
			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifySteelProduct, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifySteelProduct);
				String expectedData = " Steel & Products ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Scroll to Member Type
	public void scrollToMemberType() {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.memberType, 20);
			helper.javascriptScroll(MoreCategoriesUI.memberType);
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.memberType, 20);
				String actualData = helper.getText(MoreCategoriesUI.memberType);
				String expectedData = "Member Type";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the steel product
	public void clickDiamondMember() {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.diamondMember, 20);
			helper.clickOnElement(MoreCategoriesUI.diamondMember);

			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyDiamond, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyDiamond);
				String expectedData = "Diamond Member";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}
	
	/*---------------Testcase-13---------------*/
	public void compaireProduct() {
		clickOnMoreCategories();
		clickHomeAndSecurity();
		clickOnSofa();
		clickFirstProduct();
		scrollFirstProductAddInquary();
		clickFirstProductInFindsimilar();
		scrollFirstProductAddInquary();

	}

	// Click the Home and Security
	public void clickHomeAndSecurity() {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.homeSecurity, 20);
			helper.clickOnElement(MoreCategoriesUI.homeSecurity);

			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyHomeSecurity, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyHomeSecurity);
				String expectedData = "Home & Security";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the Sofa
	public void clickOnSofa() {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.sofa, 20);
			helper.clickOnElement(MoreCategoriesUI.sofa);
			helper.switchToNewWindow();
			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifySofa, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifySofa);
				String expectedData = " Sofa ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
				Throwable t = new RuntimeException("A runtime exception");
				Hooks.test.fail(t);
				Hooks.test.log(Status.FAIL, t);
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the FirstProduct
	public void clickFirstProduct() {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.firstProduct, 20);
			helper.clickOnElement(MoreCategoriesUI.firstProduct);
			helper.switchToNewWindow();
			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyProductDetails, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyProductDetails);
				String expectedData = "Product Details";
				helper.softAssertContaing(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the Scroll & click FirstProduct add inquary
	public void scrollFirstProductAddInquary() {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.addInquary, 20);
			helper.javascriptScroll(MoreCategoriesUI.addInquary);
			helper.clickOnElement(MoreCategoriesUI.addInquary);

			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.addInquary, 20);
				String actualData = helper.getText(MoreCategoriesUI.addInquary);
				String expectedData = "Add Inquiry Basket to Compare ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}
	
	// Click the Find similar product
		public void clickFirstProductInFindsimilar() {
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.findSimilar, 20);
				helper.javascriptScroll(MoreCategoriesUI.findSimilar);
				helper.clickOnElement(MoreCategoriesUI.clickFirstProduct);
				helper.switchToNewWindow();
				// verifySteelProduct Service
				try {
					helper.waitForElementToBeVisible(MoreCategoriesUI.clickFirstProduct, 20);
					String actualData = helper.getText(MoreCategoriesUI.clickFirstProduct);
					String expectedData = "Product Details";
					helper.softAssertContaing(actualData, expectedData);
					System.out.println(actualData);
					LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
					Hooks.test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
				} catch (Exception e) {
					LoggerGeneretor.error("Verify the Product List Fail");
					Hooks.test.log(Status.FAIL, "Verify the Product List Fail");
					String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
					Hooks.test.addScreenCaptureFromPath(screenshotPath, "ProductList");
				}

			} catch (Exception e) {
				LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
				Hooks.test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
			}
		}

	/*---------------Testcase-14---------------*/

//	public void subscribeProductAlertForLaptop() {
//		clickOnMoreCategories();
//		scrollToHavenotFound();
//		clickOnSubscribeProduct();
//		clickOnInputField();
//		clickOnConfirmButton();
//		
//	}

	// Click the Subscribe Now
	public void clickOnSubscribeProduct() {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.subscribeNow, 20);
			helper.clickOnElement(HavenotFoundProductUI.subscribeNow);
			helper.switchToNewWindow();
			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.subscribeProdAlert, 20);
				String actualData = helper.getText(HavenotFoundProductUI.subscribeProdAlert);
				String expectedData = "Subscribe to Product Alert";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the input field and search
//	public void clickOnInputField(ExtentTest test,int row, int col) {
		public void clickOnInputField(String stringData) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.inputField, 20);
			helper.clickOnElement(HavenotFoundProductUI.inputField);

			helper.sendKeys(HavenotFoundProductUI.inputField, stringData);
			System.out.println(stringData);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.inputField, 20);
				String actualData = helper.getText(HavenotFoundProductUI.inputField);
				String expectedData = "Laptop";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the clickOnConfirmButton
	public void clickOnConfirmButton() {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.confirm, 20);
			helper.clickOnElement(HavenotFoundProductUI.confirm);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.product, 20);
				String actualData = helper.getText(HavenotFoundProductUI.product);
				String expectedData = "Computer Products >> Computer Products";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}
	/*---------------Testcase-15---------------*/

//	public void subscribeProductAlertForInvalidInput() {
//		clickOnMoreCategories();
//		scrollToHavenotFound();
//		clickOnSubscribeProduct();
//		clickOnInputFieldPassInvalidInput();
//		clickOnInputFieldPassInvalidInput();
//
//	}

	// Click the input field and search
	public void clickOnInputFieldPassInvalidInput(String stringData) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.inputField, 20);
			helper.clickOnElement(HavenotFoundProductUI.inputField);			
			helper.sendKeys(HavenotFoundProductUI.inputField, stringData);
			System.out.println(stringData);
			
			Throwable expectedError = new RuntimeException("A runtime exception");
			Hooks.test.fail(expectedError);
			Hooks.test.log(Status.FAIL, expectedError);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.inputField, 20);
				String actualData = helper.getText(HavenotFoundProductUI.inputField);
				String expectedData = "iiiiiiinnnnnnnnnvvvvvaaaaaaalllllllliiiiiiiidddddd";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
				String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the clickOnConfirmButton
	public void clickOnConfirmButtonWithInvalidInput() {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.confirm, 20);
			helper.clickOnElement(HavenotFoundProductUI.confirm);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.invalidProduct, 20);
				String actualData = helper.getText(HavenotFoundProductUI.invalidProduct);
				String expectedData = "No result. Please check the keyword you entered.";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}
	/*---------------Testcase-16---------------*/

//	public void subscribeProductWithValidInput() {
//		clickOnMoreCategories();
//		scrollToHavenotFound();
//		clickOnSubscribeProduct();
//		clickOnInputField();
//		clickOnConfirmButton();
//		clickOnSubscribeButtonToSubscribe();
//
//	}

	// Click the subscribe button
	public void clickOnSubscribeButtonToSubscribe() {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.clickSubscribebutton, 20);
			helper.javascriptScroll(HavenotFoundProductUI.clickSubscribebutton);
			helper.clickOnElement(HavenotFoundProductUI.clickSubscribebutton);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.verifySignIn, 20);
				String actualData = helper.getText(HavenotFoundProductUI.verifySignIn);
				String expectedData = "Sign in with";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				Hooks.test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
				
				
				
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				Hooks.test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				Hooks.test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}
			CaptureScreenshot.captureScreenShot("Alert");

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			Hooks.test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			Hooks.test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

}
