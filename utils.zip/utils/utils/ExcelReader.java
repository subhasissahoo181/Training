package utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
//import org.apache.poi.xssf.usermodel.XSSFSheet;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ExcelReader {

public static String readData(String path, String sheet, int row, int col) {
    String data = "";
    try (FileInputStream fi = new FileInputStream(path);
         XSSFWorkbook workbook = new XSSFWorkbook(fi)) {
        XSSFSheet s = workbook.getSheet(sheet);
        if (s != null) {
            data = s.getRow(row-1).getCell(col-1).toString();
        }
    } catch (FileNotFoundException e) {
        System.err.println("File not found: " + e.getMessage());
        // Handle file not found
    } catch (IOException e) {
        System.err.println("IO Exception: " + e.getMessage());
        // Handle IO exceptions
    }
    return data;
}

}
