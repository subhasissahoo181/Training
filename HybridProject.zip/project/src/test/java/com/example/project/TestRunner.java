package com.example.project;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.junit.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.MoreCategories;
import pages.SecureTrading;
import pages.Supplier;
import pages.ApparelDetails;
import pages.HavenotFoundProduct;
import utils.ReporterMaker;
import utils.SetUpBrowser;

public class TestRunner extends SetUpBrowser {
    ExtentReports reports;
    ExtentTest test;

    @BeforeMethod
    public void startBrowser() {
        openBrowser();
        reports = ReporterMaker.generateExtentReport("report");
    }

    MoreCategories objCategories;

    // Test-1
    @Test(description = "verifyApparelAndAccessories", priority = 1)
    public void VerifyApparelAndAccessoriesTestCase1() {
        test = reports.createTest("Verify Apparel & Accessories", "TestCase-1");
        objCategories = new MoreCategories(driver);
        objCategories.verifyApparelAndAccessories(test);
    }

    // Test-2
//    @Test(description = "Filter product with valid input", priority = 2)
    public void FilterWithValidInputTeseCase2() {
        test = reports.createTest("Filter Product With Valid Input", "TestCase-2");
        objCategories = new MoreCategories(driver);
        objCategories.secureTradingWithValidInput(test);
    }

    // Test-3
//    @Test(description = "Filter product with Invalid input", priority = 3)
    public void isFilterWithInValidInputTeseCase3() {
        test = reports.createTest("Filter Product With InValid Input", "TestCase-3");
        objCategories = new MoreCategories(driver);
        objCategories.secureTradingWithInValidInput(test);
    }

    // Test-4
//    @Test(description = "clickChemicalMineral", priority = 4)
    public void isChemicalMineralsTeseCase4() {
        test = reports.createTest("ChemicalMinerals", "TestCase-4");
        objCategories = new MoreCategories(driver);
        objCategories.clickChemicalMineral(test);
    }

    // Test-5
//    @Test(description = "ShoesDetails", priority = 5)
    public void isShoesDetailsTestCase5() {
        test = reports.createTest("ShoesDetails", "TestCase-5");
        ApparelDetails objShoesDetails = new ApparelDetails(driver);
        objShoesDetails.moreShoesDetails(test);
    }

    // Test-6
//    @Test(description = "fashionAccessories", priority = 6)
    public void fashionAccessoriesDetails() {
        test = reports.createTest("fashionAccessories", "TestCase-6");
        ApparelDetails objShoesDetails = new ApparelDetails(driver);
        objShoesDetails.fashionAccessories(test);
    }

    // Test-7
//    @Test(description = "fashionAccessoriesContactSupport", priority = 7)
    public void fashionAccessoriesContactSupportDetails() {
        test = reports.createTest("fashionAccessories", "TestCase-7");
        ApparelDetails objShoesDetails = new ApparelDetails(driver);
        objShoesDetails.fashionAccessoriesContactSupport(test);
    }

    // Test-8
//    @Test(description = "fashionAccessoriesContactSupport", priority = 8)
    public void verifyUS$inProductPageInGiftBoxAndBag() {
        test = reports.createTest("fashionAccessories", "TestCase-8");
        ApparelDetails objShoesDetails = new ApparelDetails(driver);
        objShoesDetails.verifyUS$inProductPage(test);
    }

    // Test-9
//    @Test(description = "Supplier", priority = 9)
    public void supplierDetailsForProduct() {
        test = reports.createTest("Supplier", "TestCase-9");
        Supplier objSupplierDetails = new Supplier(driver);
        objSupplierDetails.supplyOpticalFiber(test);
    }

    // Test-10
//    @Test(description = "SupplyOpticalFiber", priority = 10)
    public void supplyOpticalFiber() {
        test = reports.createTest("SupplyOpticalFiber", "TestCase-10");
        Supplier objSupplierDetails = new Supplier(driver);
        objSupplierDetails.supplierDetails(test);
    }

    // Test-11
//    @Test(description = "SupplyOpticalFiber", priority = 11)
    public void souricingRequestDrtails() {
        test = reports.createTest("SupplyOpticalFiber", "TestCase-11");
        HavenotFoundProduct ObjHavenotFoundProduct = new HavenotFoundProduct(driver);
        ObjHavenotFoundProduct.souricingRequest(test);
    }

    // Test-12
//    @Test(description = "diamondMembers", priority = 12)
    public void diamondMembersDetails() {
        test = reports.createTest("diamondMembers", "TestCase-12");
        objCategories = new MoreCategories(driver);
        objCategories.diamondMembers(test);
    }

    // Test-13
//    @Test(description = "compaireTwoProduct", priority = 13)
    public void compaireTwoProduct() {
        test = reports.createTest("compaireTwoProduct", "TestCase-13");
        objCategories = new MoreCategories(driver);
        objCategories.compaireProduct(test);
    }

    // Test-14
//    @Test(description = "SubscribeProductAlert", priority = 14)
    public void subscribeProductAlert() {
        test = reports.createTest("SupplyOpticalFiber", "TestCase-14");
        HavenotFoundProduct ObjHavenotFoundProduct = new HavenotFoundProduct(driver);
        ObjHavenotFoundProduct.subscribeProductAlertForLaptop(test);
    }

    // Test-15
//    @Test(description = "SubscribeProductAlert", priority = 15)
    public void subscribeProductAlertForInvalidInput() {
        test = reports.createTest("SupplyOpticalFiber", "TestCase-15");
        HavenotFoundProduct ObjHavenotFoundProduct = new HavenotFoundProduct(driver);
        ObjHavenotFoundProduct.subscribeProductAlertForInvalidInput(test);
    }

    // Test-16
//    @Test(description = "SubscribeProductWithValidInput", priority = 16)
    public void subscribeProductWithValidInputDetails() {
        test = reports.createTest("SubscribeProductWithValidInput", "TestCase-16");
        HavenotFoundProduct ObjHavenotFoundProduct = new HavenotFoundProduct(driver);
        ObjHavenotFoundProduct.subscribeProductWithValidInput(test);
    }

    // Test-17
//    @Test(description = "orderProductWithMoreSefty", priority = 17)
    public void orderProductWithMoreSefty() {
        test = reports.createTest("orderProductWithMoreSefty", "TestCase-17");
        SecureTrading ObjSecureTrading = new SecureTrading(driver);
        ObjSecureTrading.orderProductWithMoreSefty(test);
    }

    // Test-18
//    @Test(description = "orderProductRange", priority = 18)
    public void orderProductRange() {
        test = reports.createTest("orderProductRange", "TestCase-16");
        SecureTrading ObjSecureTrading = new SecureTrading(driver);
        ObjSecureTrading.orderProductRange(test);
    }

    // Test-19
//    @Test(description = "productEasySourcing", priority = 19)
    public void productEasySourcing() {
        test = reports.createTest("productEasySourcing", "TestCase-16");
        SecureTrading ObjSecureTrading = new SecureTrading(driver);
        ObjSecureTrading.productEasySourcing(test);
    }

    // Test-20
//    @Test(description = "buyPoloTshirt", priority = 20)
    public void buyPoloTshirt() {
        test = reports.createTest("buyPoloTshirt", "TestCase-16");
        SecureTrading ObjSecureTrading = new SecureTrading(driver);
        ObjSecureTrading.buyPoloTshirt(test);
    }

    // Test-21
//    @Test(description = "orderProductOverWorld", priority = 20)
    public void orderProductOverWorld() {
        test = reports.createTest("orderProductOverWorld", "TestCase-16");
        SecureTrading ObjSecureTrading = new SecureTrading(driver);
        ObjSecureTrading.orderProductOverWorld(test);
    }

    // AfterMethod
    @AfterMethod
    public void endTheBrowser() {
        driver.quit();
    }

    // Flush
    @AfterTest
    public void isFlush() {
        reports.flush();
    }

    @AfterClass
    public static void sendingMail() throws AddressException, IOException, MessagingException {
        Mailing sendMail = new Mailing();
        try {
            sendMail.mail();
            System.out.println("Report has been sent");
        } catch (IOException | MessagingException e) {
            e.printStackTrace();
        }
    }
}