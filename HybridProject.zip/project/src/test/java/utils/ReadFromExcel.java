package utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadFromExcel {

	public static FileInputStream file;
	public static XSSFWorkbook workbook;
	public static XSSFSheet sheet;
	public static FileOutputStream fileout;
	public static XSSFRow row;
	public static XSSFCell col;
	public static int rowvalue;
	public static int colvalue;

	public static String readdata(int rownumber, int colnumber) throws IOException

	{
		try {
			String filepath=System.getProperty("user.dir")+"/testdata/data.xlsx";
			file = new FileInputStream(filepath);
			workbook = new XSSFWorkbook(file);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		sheet = workbook.getSheet("Sheet1");
		row = sheet.getRow(rownumber);
		col = row.getCell(colnumber);

		// String value = col.toString();
		String value;

		try {
			DataFormatter d = new DataFormatter();
			value = d.formatCellValue(col);
			return value;

		} catch (Exception e) {
			value = "";
		}
		workbook.close();
		file.close();
		return value;

	}
	
	public static String readData(String path, String sheet, int row, int col) {
	    String data = "";
	    try (FileInputStream fi = new FileInputStream(path);
	         XSSFWorkbook workbook = new XSSFWorkbook(fi)) {
	        XSSFSheet s = workbook.getSheet(sheet);
	        if (s != null) {
	            data = s.getRow(row-1).getCell(col-1).toString();
	        }
	    } catch (FileNotFoundException e) {
	        System.err.println("File not found: " + e.getMessage());
	        // Handle file not found
	    } catch (IOException e) {
	        System.err.println("IO Exception: " + e.getMessage());
	        // Handle IO exceptions
	    }
	    return data;
	}


	public static void writedata(String filepath, String sheetname, int rownumber, int colnumber, String value)
			throws IOException {
		try {
			file = new FileInputStream(filepath);
			workbook = new XSSFWorkbook(file);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		sheet = workbook.getSheet(sheetname);

		row = sheet.getRow(rownumber);

		col = row.getCell(colnumber);

		col.setCellValue(value);

		try {
			fileout = new FileOutputStream(filepath);
			workbook.write(fileout);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		workbook.close();

		file.close();

		fileout.close();

	}

}
