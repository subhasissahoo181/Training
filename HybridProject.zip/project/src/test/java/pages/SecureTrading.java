package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.HavenotFoundProductUI;
import uistore.MoreCategoriesUI;
import utils.CaptureScreenshot;
import utils.DriverHelper;
import utils.LoggerGeneretor;
import utils.ReadFromExcel;
import utils.ReporterMaker;

public class SecureTrading {
	WebDriver driver;
	DriverHelper helper;

	public SecureTrading(WebDriver driver) {
		this.driver = driver;
		helper = new DriverHelper(driver);
	}

	/*-----------TestCase-17-----------------*/
	/*
	 * Method Name:- isVerifyApparelAndAccessories() Author Name:-
	 * SubhasisSahoo(10820896) Short Description Of Method:- Open the application
	 * through the website URL and Verify that the user can browse various product
	 * categories. Return Type:- Void Parameter LIst:- test
	 */
	public void orderProductWithMoreSefty(ExtentTest test) {
		clickOnMoreCategories(test);
		clickApparelAndLight(test);
		clickShoesFromApparelLight(test);
		clickStartOrderInSecureTrading(test);
		verifySecureTradingForProduct(test);
	}

	// Click the More Categories link
	public void clickOnMoreCategories(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.moreCategories, 20);
			helper.clickOnElement(MoreCategoriesUI.moreCategories);
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.chinaProductsDirectory, 20);
				String actualData = helper.getText(MoreCategoriesUI.chinaProductsDirectory);
				String expectedData = "China Products Directory";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	public void clickApparelAndLight(ExtentTest test) {
		// Click the Apparel & Light Industry
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.apparelandLight, 20);
			helper.clickOnElement(MoreCategoriesUI.apparelandLight);

			// Verify Apparel & Light Industry Heading
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyApparelandLight, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyApparelandLight);
				String expectedData = "Apparel & Light Industry";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the " + actualData + " Pass");
				test.log(Status.PASS, "Click and Verify the " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Apparel & Light Industry Fail");
				test.log(Status.FAIL, "Verify the Apparel & Light Industry Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ApparelandLightIndustry");
				test.addScreenCaptureFromPath(screenshotPath, "ApparelandLightIndustry");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Apparel & Light Industry Fail");
			test.log(Status.FAIL, "Click on Apparel & Light Industry Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ApparelAndLight");
			test.addScreenCaptureFromPath(screenshotPath, "ApparelAndLight");
		}

	}

	// Click the shoes from the ApparelLight link
	public void clickShoesFromApparelLight(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.shoes, 20);
			helper.clickOnElement(MoreCategoriesUI.shoes);
			helper.switchToNewWindow();
			// Verify the shoes product title is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyProductCategories, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyProductCategories);
				String expectedData = " Shoes ";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the  Shoes  Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the  Shoes  Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the  Shoes  Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the  Shoes  Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("Shoes");
				test.addScreenCaptureFromPath(screenshotPath, "Shoes");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the Start order link
	public void clickStartOrderInSecureTrading(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.startOrder, 20);
			helper.clickOnElement(MoreCategoriesUI.startOrder);
			helper.switchToNewWindow();
			// Verify the shoes product title is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifySecureTrading, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifySecureTrading);
				String expectedData = "Secured Trading";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the  Secured Trading title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the  Secured Trading title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the  Secured Trading title is  Fail");
				test.log(Status.FAIL, "Click and Verify the  Secured Trading title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("SecuredTrading");
				test.addScreenCaptureFromPath(screenshotPath, "SecuredTrading");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Verify Secure Trading
	public void verifySecureTradingForProduct(ExtentTest test) {

		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.verifySecureTrading, 20);
			String actualData = helper.getText(MoreCategoriesUI.verifySecureTrading);
			String expectedData = "Secured Trading";
			helper.softAsserting(actualData, expectedData);
			LoggerGeneretor.info("Verify the  Secured Trading title is " + actualData + " Pass");
			test.log(Status.PASS, "Verify the  Secured Trading title is " + actualData + " Pass");
		} catch (Exception e) {
			LoggerGeneretor.error("Click and Verify the  Secured Trading title is  Fail");
			test.log(Status.FAIL, "Click and Verify the  Secured Trading title is  Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("SecuredTrading");
			test.addScreenCaptureFromPath(screenshotPath, "SecuredTrading");
		}
		CaptureScreenshot.captureScreenShot("SecuredTrading");

	}

	/*--------------------TestCase-18--------------------------------------*/

	public void orderProductRange(ExtentTest test) {
		clickOnMoreCategories(test);
		clickApparelAndLight(test);
		clickChildrenApparelFromApparel(test);
		scrollToTheAge(test);
		clickTheAgeRanged(test);
		verifyTheAgeRangeCapdtureScreenShort(test);
	}

	// Click the children Apparel link
	public void clickChildrenApparelFromApparel(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.childrenApperal, 20);
			helper.clickOnElement(MoreCategoriesUI.childrenApperal);
			helper.switchToNewWindow();
			// Verify the shoes product title is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyProductCategories, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyProductCategories);
				String expectedData = " Children's Apparel ";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   Children's Apparel  title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   Children's Apparel  title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the   Children's Apparel  title is  Fail");
				test.log(Status.FAIL, "Click and Verify the   Children's Apparel  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("SecuredTrading");
				test.addScreenCaptureFromPath(screenshotPath, "SecuredTrading");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// verify the Age and scrollToTheAged
	public void scrollToTheAge(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.age, 20);
			helper.javascriptScroll(MoreCategoriesUI.age);

			// Verify the shoes product title is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.age, 20);
				String actualData = helper.getText(MoreCategoriesUI.age);
				String expectedData = "Age";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   Children's Apparel Age title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   Children's Apparel Age  title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the   Children's Apparel Age  title is  Fail");
				test.log(Status.FAIL, "Click and Verify the   Children's Apparel Age title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("Age");
				test.addScreenCaptureFromPath(screenshotPath, "Age");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Scroll to Age Fail");
			test.log(Status.FAIL, "Scroll to Age Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ScrollAge");
			test.addScreenCaptureFromPath(screenshotPath, "ScrollAge");
		}

	}

	// Click the Age 2-6 year link
	public void clickTheAgeRanged(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.ageRange, 20);
			helper.clickOnElement(MoreCategoriesUI.ageRange);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyAge, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyAge);
				String expectedData = "2-6 Years";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   Children's Apparel Age title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the  Children's Apparel  Age title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the 2-6 Years  Children's Apparel  title is  Fail");
				test.log(Status.FAIL, "Click and Verify the 2-6 Years  Children's Apparel  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("2-6_Years");
				test.addScreenCaptureFromPath(screenshotPath, "2-6_Years");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on 2-6 Years link Fail");
			test.log(Status.FAIL, "Click on 2-6 Years link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("2-6_Years_Fail");
			test.addScreenCaptureFromPath(screenshotPath, "2-6_Years_Fail");
		}

	}

	// Verify 2-6 Year
	public void verifyTheAgeRangeCapdtureScreenShort(ExtentTest test) {

		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.verifyAge, 20);
			String actualData = helper.getText(MoreCategoriesUI.verifyAge);
			String expectedData = "2-6 Years";
			helper.softAsserting(actualData, expectedData);
			LoggerGeneretor.info("Verify the   Children's Apparel Age title is " + actualData + " Pass");
			test.log(Status.PASS, "Verify the  Children's Apparel  Age title is " + actualData + " Pass");
		} catch (Exception e) {
			LoggerGeneretor.error("Click and Verify the 2-6 Years  Children's Apparel  title is  Fail");
			test.log(Status.FAIL, "Click and Verify the 2-6 Years  Children's Apparel  title is  Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("2-6_Years_Fail");
			test.addScreenCaptureFromPath(screenshotPath, "2-6_Years_Fail");
		}
		CaptureScreenshot.captureScreenShot("2-6_Years");

	}

	/*--------------------TestCase-19--------------------------------------*/

	public void productEasySourcing(ExtentTest test) {
		scrollToEasySourcing(test);
		clickProductNameKeywordInputField(test);
		clickPostYourRequestButton(test);
		VerifyTheInputField(test);

	}

	// Click the Age 2-6 year link
	public void scrollToEasySourcing(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.easySourcing, 20);
			helper.javascriptScroll(MoreCategoriesUI.easySourcing);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.easySourcing, 20);
				String actualData = helper.getText(MoreCategoriesUI.easySourcing);
				String expectedData = "EASY SOURCING";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   EASY SOURCING title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the  EASY SOURCING title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the EASY SOURCING  title is  Fail");
				test.log(Status.FAIL, "Click and Verify the EASY SOURCING  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("EASYSOURCING");
				test.addScreenCaptureFromPath(screenshotPath, "EASYSOURCING");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Scroll on EASY SOURCING link Fail");
			test.log(Status.FAIL, "Scroll on EASY SOURCING Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("EASYSOURCING");
			test.addScreenCaptureFromPath(screenshotPath, "EASYSOURCING");
		}

	}

	// click ProductName Keyword InputField
	public void clickProductNameKeywordInputField(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.productNameInput, 20);
			helper.clickOnElement(MoreCategoriesUI.productNameInput);
			// Send the data from excel
			String excelData = ReadFromExcel.readdata(10, 4);
			helper.sendKeys(MoreCategoriesUI.productNameInput, excelData);
			System.out.println(excelData);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.productNameInput, 20);
				String actualData = helper.getText(MoreCategoriesUI.productNameInput);
				String expectedData = "Tshirt";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the  productNameInput title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the productNameInput title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify productNameInput is  Fail");
				test.log(Status.FAIL, "Click and Verify productNameInput  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("productNameInput");
				test.addScreenCaptureFromPath(screenshotPath, "productNameInput");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on productNameInput link Fail");
			test.log(Status.FAIL, "Click on productNameInput link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("productNameInput");
			test.addScreenCaptureFromPath(screenshotPath, "productNameInput");
		}

	}

	// Click the postRequestNow button
	public void clickPostYourRequestButton(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.postRequestNow, 20);
			helper.clickOnElement(MoreCategoriesUI.postRequestNow);
			helper.switchToNewWindow();
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyInputValue, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyInputValue);
				String expectedData = "Tshirt";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the  verifyInputValue title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the  verifyInputValue title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verifyInputValue  title is  Fail");
				test.log(Status.FAIL, "Click and verifyInputValue  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyInputValue");
				test.addScreenCaptureFromPath(screenshotPath, "verifyInputValue");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verifyInputValue link Fail");
			test.log(Status.FAIL, "Click on verifyInputValue link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyInputValue");
			test.addScreenCaptureFromPath(screenshotPath, "verifyInputValue");
		}

	}

	// VerifyTheInputField
	public void VerifyTheInputField(ExtentTest test) {

		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.verifyInputValue, 20);
			String actualData = helper.getText(MoreCategoriesUI.verifyInputValue);
			String expectedData = "Tshirt";
			helper.softAsserting(actualData, expectedData);
			LoggerGeneretor.info("Verify the  verifyInputValue title is " + actualData + " Pass");
			test.log(Status.PASS, "Verify the  verifyInputValue title is " + actualData + " Pass");
		} catch (Exception e) {
			LoggerGeneretor.error("Click and verifyInputValue  title is  Fail");
			test.log(Status.FAIL, "Click and verifyInputValue  title is  Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyInputValue");
			test.addScreenCaptureFromPath(screenshotPath, "verifyInputValue");
		}
		CaptureScreenshot.captureScreenShot("verifyInputValue");

	}
	/*--------------------TestCase-20--------------------------------------*/

	public void buyPoloTshirt(ExtentTest test) {
		clickOnMoreCategories(test);
		clickApparelAndLight(test);
		clickTshirt(test);
		clickPoloTshirt(test);
		clickFirstProduct(test);
		clickProductDetails(test);
		verifyTheModel(test);

	}

	// Click the postRequestNow button
	public void clickTshirt(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.tShirt, 20);
			helper.clickOnElement(MoreCategoriesUI.tShirt);
			helper.switchToNewWindow();
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyTshirt, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyTshirt);
				String expectedData = " T-Shirt ";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   T-Shirt  title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   T-Shirt  title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and  T-Shirt   title is  Fail");
				test.log(Status.FAIL, "Click and  T-Shirt   title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot(" T-Shirt ");
				test.addScreenCaptureFromPath(screenshotPath, " T-Shirt ");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on  T-Shirt  link Fail");
			test.log(Status.FAIL, "Click on  T-Shirt  link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyInputValue");
			test.addScreenCaptureFromPath(screenshotPath, "verifyInputValue");
		}

	}

	// Click the postRequestNow button
	public void clickPoloTshirt(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.poloTshirt, 20);
			helper.clickOnElement(MoreCategoriesUI.poloTshirt);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.poloTshirt, 20);
				String actualData = helper.getText(MoreCategoriesUI.poloTshirt);
				String expectedData = "Polo Shirt";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the  verifyInputValue title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the  verifyInputValue title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verifyInputValue  title is  Fail");
				test.log(Status.FAIL, "Click and verifyInputValue  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyInputValue");
				test.addScreenCaptureFromPath(screenshotPath, "verifyInputValue");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verifyInputValue link Fail");
			test.log(Status.FAIL, "Click on verifyInputValue link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyInputValue");
			test.addScreenCaptureFromPath(screenshotPath, "verifyInputValue");
		}

	}

	// Click the FirstProduct
	public void clickFirstProduct(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.firstProduct, 20);
			helper.clickOnElement(MoreCategoriesUI.firstProduct);
			helper.switchToNewWindow();
			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyProductDetails, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyProductDetails);
				String expectedData = "Product Details";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the postRequestNow button
	public void clickProductDetails(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.verifyProductDetails, 20);
			helper.clickOnElement(MoreCategoriesUI.verifyProductDetails);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.modelNumber, 20);
				String actualData = helper.getText(MoreCategoriesUI.modelNumber);
				String expectedData = "Model NO.";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verify Model NO.  title is  Fail");
				test.log(Status.FAIL, "Click and verify Model NO.  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
				test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verify Model NO. link Fail");
			test.log(Status.FAIL, "Click on verifyI Model NO. link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
			test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
		}

	}

	public void verifyTheModel(ExtentTest test) {
		// Verify the age range is present.
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.modelNumber, 20);
			String actualData = helper.getText(MoreCategoriesUI.modelNumber);
			String expectedData = "Model NO.";
			helper.softAsserting(actualData, expectedData);
			LoggerGeneretor.info("Verify the   title is " + actualData + " Pass");
			test.log(Status.PASS, "Verify the   title is " + actualData + " Pass");
		} catch (Exception e) {
			LoggerGeneretor.error("Click and verify Model NO.  title is  Fail");
			test.log(Status.FAIL, "Click and verify Model NO.  title is  Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
			test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
		}

	}
	

	/*--------------------TestCase-21--------------------------------------*/

	public void orderProductOverWorld(ExtentTest test) {
		clickOnMoreCategories(test);
		clickTransportation(test);
		clickBike(test);
		clickSupplierList(test);
		scrollProvinence(test);
		clickTheRegion(test);
//		verifyRegion(test);

	}

	// Click the postRequestNow button
	public void clickTransportation(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.transpotation, 20);
			helper.clickOnElement(MoreCategoriesUI.transpotation);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyTransport, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyTransport);
				String expectedData = "Transportation & Sporting Goods";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verify Transportation & Sporting Goods.  title is  Fail");
				test.log(Status.FAIL, "Click and verify Transportation & Sporting Goods.  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
				test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verify Model NO. link Fail");
			test.log(Status.FAIL, "Click on verifyI Model NO. link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
			test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
		}

	}

	// Click the postRequestNow button
	public void clickBike(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.bike, 20);
			helper.clickOnElement(MoreCategoriesUI.bike);
			helper.switchToNewWindow();
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyBike, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyBike);
				String expectedData = "Bike";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verify Model NO.  title is  Fail");
				test.log(Status.FAIL, "Click and verify Model NO.  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
				test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verify Model NO. link Fail");
			test.log(Status.FAIL, "Click on verifyI Model NO. link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
			test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
		}

	}

	// Click the Supplier List button
	public void clickSupplierList(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.supplierList, 20);
			helper.clickOnElement(MoreCategoriesUI.supplierList);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.supplierList, 20);
				String actualData = helper.getText(MoreCategoriesUI.supplierList);
				String expectedData = "Supplier List";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verify Model NO.  title is  Fail");
				test.log(Status.FAIL, "Click and verify Model NO.  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
				test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verify Model NO. link Fail");
			test.log(Status.FAIL, "Click on verifyI Model NO. link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
			test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
		}

	}

	// Click the postRequestNow button
	public void scrollProvinence(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.provinceRegion, 20);
			helper.javascriptScroll(MoreCategoriesUI.provinceRegion);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.provinceRegion, 20);
				String actualData = helper.getText(MoreCategoriesUI.provinceRegion);
				String expectedData = "Province & Region";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verify Model NO.  title is  Fail");
				test.log(Status.FAIL, "Click and verify Model NO.  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
				test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verify Model NO. link Fail");
			test.log(Status.FAIL, "Click on verifyI Model NO. link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
			test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
		}

	}

	// Click the postRequestNow button
	public void clickTheRegion(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.gungdong, 20);
			helper.clickOnElement(MoreCategoriesUI.gungdong);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyGungdong, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyGungdong);
				String expectedData = "Guangdong";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verify Model NO.  title is  Fail");
				test.log(Status.FAIL, "Click and verify Model NO.  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
				test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verify Model NO. link Fail");
			test.log(Status.FAIL, "Click on verifyI Model NO. link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
			test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
		}

	}

	public void verifyRegion(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.provinceRegion, 20);
			helper.javascriptScroll(MoreCategoriesUI.provinceRegion);
			// Verify the age range is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyGungdong, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyGungdong);
				String expectedData = "Guangdong";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the   title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the   title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and verify Model NO.  title is  Fail");
				test.log(Status.FAIL, "Click and verify Model NO.  title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
				test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on verify Model NO. link Fail");
			test.log(Status.FAIL, "Click on verifyI Model NO. link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("verifyModel");
			test.addScreenCaptureFromPath(screenshotPath, "verifyModel");
		}
	}

}
