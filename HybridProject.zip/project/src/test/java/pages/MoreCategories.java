package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.ChemicalMineralsUI;
import uistore.FilterWithValidInputUI;
import uistore.MoreCategoriesUI;
import utils.DriverHelper;
import utils.LoggerGeneretor;
import utils.ReadFromExcel;
import utils.ReporterMaker;
import utils.CaptureScreenshot;

public class MoreCategories {
	WebDriver driver;
	DriverHelper helper;

	public MoreCategories(WebDriver driver) {
		this.driver = driver;
		helper = new DriverHelper(driver);
	}

	/*
	 * Method Name:- isVerifyApparelAndAccessories() Author Name:-
	 * SubhasisSahoo(10820896) Short Description Of Method:- Open the application
	 * through the website URL and Verify that the user can browse various product
	 * categories. Return Type:- Void Parameter LIst:- test
	 */
	public void verifyApparelAndAccessories(ExtentTest test) {
		clickOnMoreCategories(test);
		clickApparelAndLight(test);
		clickApparelAndAccessories(test);
	}

	/*
	 * Method-1 for step-1 Method Name:- ClickOnMoreCategories() Author Name:-
	 * SubhasisSahoo(10820896) Short Description Of Method:- Open the application
	 * through the website URL and Verify that the user can browse various product
	 * categories. Return Type:- Void Parameter LIst:- test
	 */
	
	// Click the More Categories link
	public void clickOnMoreCategories(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.moreCategories, 20);
			helper.clickOnElement(MoreCategoriesUI.moreCategories);
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.chinaProductsDirectory, 20);
				String actualData = helper.getText(MoreCategoriesUI.chinaProductsDirectory);
				String expectedData = "China Products Directory";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}
	/*
	 * Method-2 for step-2 Method Name:- ClickApparelAndLight() Author Name:-
	 * SubhasisSahoo(10820896) Short Description Of Method:- Open the application
	 * through the website URL and Verify that the user can browse various product
	 * categories. Return Type:- Void Parameter LIst:- test
	 */

	public void clickApparelAndLight(ExtentTest test) {
		// Click the Apparel & Light Industry
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.apparelandLight, 20);
			helper.clickOnElement(MoreCategoriesUI.apparelandLight);

			// Verify Apparel & Light Industry Heading
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyApparelandLight, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyApparelandLight);
				String expectedData = "Apparel & Light Industry";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the " + actualData + " Pass");
				test.log(Status.PASS, "Click and Verify the " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Apparel & Light Industry Fail");
				test.log(Status.FAIL, "Verify the Apparel & Light Industry Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ApparelandLightIndustry");
				test.addScreenCaptureFromPath(screenshotPath, "ApparelandLightIndustry");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Apparel & Light Industry Fail");
			test.log(Status.FAIL, "Click on Apparel & Light Industry Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ApparelAndLight");
			test.addScreenCaptureFromPath(screenshotPath, "ApparelAndLight");
		}

	}

	/*
	 * Method-3 for step-3 Method Name:- isClickApparelAndAccessories() Author
	 * Name:- SubhasisSahoo(10820896) Short Description Of Method:- Open the
	 * application through the website URL and Verify that the user can browse
	 * various product categories. Return Type:- Void Parameter LIst:- test
	 */
	public void clickApparelAndAccessories(ExtentTest test) {

		// Click the Apparel & Accessories
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.clickApparelandAccessories, 20);
			helper.clickOnElement(MoreCategoriesUI.clickApparelandAccessories);
			helper.switchToNewWindow();

			// Verify the Apparel & Accessories title
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyApparelandAccessories, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyApparelandAccessories);
				String expectedData = "Apparel & Accessories";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify " + actualData + " title Pass");
				test.log(Status.PASS, "Click and Verify " + actualData + " title Pass");

			} catch (Exception e) {
				LoggerGeneretor.error("Verify Apparel & Accessories title Fail");
				test.log(Status.FAIL, "Verify Apparel & Accessories title Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifiedApparelAndAccessories");
				test.addScreenCaptureFromPath(screenshotPath, "VerifiedApparelAndAccessories");
			}
			CaptureScreenshot.captureScreenShot("Apparel Verified");

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Apparel & Accessories Fail");
			test.log(Status.FAIL, "Click on Apparel & Accessories Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ApparelAndAccessories");
			test.addScreenCaptureFromPath(screenshotPath, "ApparelAndAccessories");
		}

	}

	/*------------------- TestCase-2 Start---------------------*/

	/*
	 * Method Name:- isVerifyApparelAndAccessories() Author Name:-
	 * SubhasisSahoo(10820896) Short Description Of Method:- Open the application
	 * through the website URL and Verify that the user can browse various product
	 * categories. Return Type:- Void Parameter LIst:- test
	 */

	public void secureTradingWithValidInput(ExtentTest test) {
		clickOnMoreCategories(test);
		clickOnHotSearches(test);
		clickOnHotSearchesFirstCategoties(test);
		clickOnSecuredTradingButtonForInvalidInput(test);
		validMaxMinRange(test);
	}

	public void validMaxMinRange(ExtentTest test) {
		clickOnMinOrderInputField(test);
		clickOnMinOrderOkButton(test);
		clickOnMinPriceInputField(test);
		clickOnMaxPriceInputField(test);
		clickOnPriceOkButton(test);
	}

	// Scroll to Hot Searches
	public void clickOnHotSearches(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.hotSearches, 20);
			helper.javascriptScroll(FilterWithValidInputUI.hotSearches);

			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.hotSearches, 20);
				String actualData = helper.getText(FilterWithValidInputUI.hotSearches);
				String expectedData = "Hot Searches";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the " + actualData + " Pass");
				test.log(Status.PASS, "Click and Verify the " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Hot Searches Fail");
				test.log(Status.FAIL, "Verify the Hot Searches Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("HotSearches");
				test.addScreenCaptureFromPath(screenshotPath, "HotSearches");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}
	}

	// Click the first categories button under HotSearches
	public void clickOnHotSearchesFirstCategoties(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.clickFirstButton, 20);
			helper.clickOnElement(FilterWithValidInputUI.clickFirstButton);
			helper.switchToNewWindow();

			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifyProductList, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifyProductList);
				String expectedData = "LED";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the " + actualData + " Pass");
				test.log(Status.PASS, "Click and Verify the " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on first categories button under HotSearches Fail");
			test.log(Status.FAIL, "Click on first categories button under HotSearches Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}
	}

	// Click the Secured Trading
	public void clickOnSecuredTradingButton(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.securedTrading, 40);
			helper.clickOnElement(FilterWithValidInputUI.securedTrading);
//			helper.jsClick(FilterWithValidInputUI.securedTrading);

			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifysecuredTrading, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifysecuredTrading);
				String expectedData = "Secured Trading Service";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the " + actualData + " Pass");
				test.log(Status.PASS, "Click and Verify the " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on first categories button under HotSearches Fail");
			test.log(Status.FAIL, "Click on first categories button under HotSearches Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}
	}

	// Click on Min Order Input Field
	public void clickOnMinOrderInputField(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.minOrder, 20);
			helper.clickOnElement(FilterWithValidInputUI.minOrder);
			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(0, 4);
			helper.sendKeys(FilterWithValidInputUI.minOrder, excelData);
			System.out.println(excelData);

			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifyMinOrder, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifyMinOrder);
				String expectedData = "Min Order:";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Input MinOrder  Fail");
			test.log(Status.FAIL, "Input MinOrder Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}

	}

	// Click on Min Order Ok button
	public void clickOnMinOrderOkButton(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.minOrderOk, 20);
			helper.clickOnElement(FilterWithValidInputUI.minOrderOk);

			// Verify minOrderOk Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.minOrderOk, 20);
				String actualData = helper.getText(FilterWithValidInputUI.minOrderOk);
				String expectedData = "OK";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Input minOrderOk  Fail");
			test.log(Status.FAIL, "Input minOrderOk Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}

	}

	// Click on Min Price Input Field
	public void clickOnMinPriceInputField(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.minPrice, 20);
			helper.clickOnElement(FilterWithValidInputUI.minPrice);
			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(1, 4);
			helper.sendKeys(FilterWithValidInputUI.minPrice, excelData);
			System.out.println(excelData);

			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifyPrice, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifyPrice);
				String expectedData = "Price:";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Input MinOrder  Fail");
			test.log(Status.FAIL, "Input MinOrder Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}

	}

	// Click on Max Price Input Field
	public void clickOnMaxPriceInputField(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.maxPrice, 20);
			helper.clickOnElement(FilterWithValidInputUI.maxPrice);
			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(2, 4);
			helper.sendKeys(FilterWithValidInputUI.maxPrice, excelData);
			System.out.println(excelData);

			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifyPrice, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifyPrice);
				String expectedData = "Price:";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Input MinOrder  Fail");
			test.log(Status.FAIL, "Input MinOrder Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}

	}

	// Click on Min Order Ok button
	public void clickOnPriceOkButton(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.priceOK, 20);
			helper.clickOnElement(FilterWithValidInputUI.priceOK);

			// Verify minOrderOk Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.minOrderOk, 20);
				String actualData = helper.getText(FilterWithValidInputUI.minOrderOk);
				String expectedData = "OK";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Input minOrderOk  Fail");
			test.log(Status.FAIL, "Input minOrderOk Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}

	}

	/*------------------- TestCase-3 Start---------------------*/

	/*
	 * Method Name:- secureTradingWithInValidInput() Author Name:-
	 * SubhasisSahoo(10820896) Short Description Of Method:- Open the application
	 * through the website URL and Verify that the user can browse various product
	 * categories. Return Type:- Void Parameter LIst:- test
	 */

	public void secureTradingWithInValidInput(ExtentTest test) {
		clickOnMoreCategories(test);
		clickOnHotSearchesForInvalidInput(test);
		clickOnHotSearchesFirstCategotiesForInvalidInput(test);
		clickOnSecuredTradingButtonForInvalidInput(test);
		inValidMaxMinRange(test);
	}

	public void inValidMaxMinRange(ExtentTest test) {
		clickOnMinOrderInputFieldForInvalidInput(test);
		clickOnMinOrderOkButton(test);
		clickOnMinPriceInputFieldForInvalidInput(test);
		clickOnMaxPriceInputFieldForInvalidInput(test);
		clickOnPriceOkButton(test);
	}

	// Scroll to Hot Searches
	public void clickOnHotSearchesForInvalidInput(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.hotSearches, 20);
			helper.javascriptScroll(FilterWithValidInputUI.hotSearches);

			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.hotSearches, 20);
				String actualData = helper.getText(FilterWithValidInputUI.hotSearches);
				String expectedData = "Hot Searches";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the " + actualData + " Pass");
				test.log(Status.PASS, "Click and Verify the " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Hot Searches Fail");
				test.log(Status.FAIL, "Verify the Hot Searches Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("HotSearches");
				test.addScreenCaptureFromPath(screenshotPath, "HotSearches");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}
	}

	// Click the first categories button under HotSearches
	public void clickOnHotSearchesFirstCategotiesForInvalidInput(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.clickFirstButton, 20);
			helper.clickOnElement(FilterWithValidInputUI.clickFirstButton);
			helper.switchToNewWindow();
			System.out.println("next page");
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifyProductList, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifyProductList);
				String expectedData = "LED";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the " + actualData + " Pass");
				test.log(Status.PASS, "Click and Verify the " + actualData + " Pass");
				System.out.println("next page4");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}
			System.out.println("next page2");

		} catch (Exception e) {
			LoggerGeneretor.error("Click on first categories button under HotSearches Fail");
			test.log(Status.FAIL, "Click on first categories button under HotSearches Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}
	}

	// Click the Secured Trading
	public void clickOnSecuredTradingButtonForInvalidInput(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.securedTrading, 40);
			helper.clickOnElement(FilterWithValidInputUI.securedTrading);
//						helper.jsClick(FilterWithValidInputUI.securedTrading);

			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifysecuredTrading, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifysecuredTrading);
				String expectedData = "Secured Trading Service";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the " + actualData + " Pass");
				test.log(Status.PASS, "Click and Verify the " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on first categories button under HotSearches Fail");
			test.log(Status.FAIL, "Click on first categories button under HotSearches Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}
	}

	// Click on Min Order Input Field
	public void clickOnMinOrderInputFieldForInvalidInput(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.minOrder, 20);
			helper.clickOnElement(FilterWithValidInputUI.minOrder);
			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(3, 4);
			helper.sendKeys(FilterWithValidInputUI.minOrder, excelData);
			System.out.println(excelData);

			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifyMinOrder, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifyMinOrder);
				String expectedData = "Min Order:";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Input MinOrder  Fail");
			test.log(Status.FAIL, "Input MinOrder Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}

	}

	// Click on Min Price Input Field
	public void clickOnMinPriceInputFieldForInvalidInput(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.minPrice, 20);
			helper.clickOnElement(FilterWithValidInputUI.minPrice);
			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(4, 4);
			helper.sendKeys(FilterWithValidInputUI.minPrice, excelData);
			System.out.println(excelData);

			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifyPrice, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifyPrice);
				String expectedData = "Price:";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Input MinOrder  Fail");
			test.log(Status.FAIL, "Input MinOrder Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}

	}

	// Click on Max Price Input Field
	public void clickOnMaxPriceInputFieldForInvalidInput(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(FilterWithValidInputUI.maxPrice, 20);
			helper.clickOnElement(FilterWithValidInputUI.maxPrice);
			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(5, 4);
			helper.sendKeys(FilterWithValidInputUI.maxPrice, excelData);
			System.out.println(excelData);

			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(FilterWithValidInputUI.verifyPrice, 20);
				String actualData = helper.getText(FilterWithValidInputUI.verifyPrice);
				String expectedData = "Price:";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Input MinOrder  Fail");
			test.log(Status.FAIL, "Input MinOrder Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstButton");
			test.addScreenCaptureFromPath(screenshotPath, "FirstButton");
		}

	}

	/*---------------Testcase-4---------------*/

	public void clickChemicalMineral(ExtentTest test) {
		clickOnMoreCategories(test);
		clickChemicalAndMinerals(test);
		clickRubberMaterial(test);
		clickTheFirstProduct(test);
		addInquaryScroll(test);
		addInquaryProduct(test);
		addInquaryCart(test);

	}

	public void clickChemicalAndMinerals(ExtentTest test) {
		// Click the Chemicals & Minerals link
		try {
			helper.waitForElementToBeVisible(ChemicalMineralsUI.chemicalAndMinerals, 20);
			helper.clickOnElement(ChemicalMineralsUI.chemicalAndMinerals);
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(ChemicalMineralsUI.verifyChemical, 20);
				String actualData = helper.getText(ChemicalMineralsUI.verifyChemical);
				String expectedData = "Chemicals & Minerals";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	public void clickRubberMaterial(ExtentTest test) {
		// Click the Rubber Materials Under Chemicals.
		try {
			helper.waitForElementToBeVisible(ChemicalMineralsUI.rubberMaterials, 20);
			helper.clickOnElement(ChemicalMineralsUI.rubberMaterials);
			helper.switchToNewWindow();
			// Verify RubberMaterial Service
			try {
				helper.waitForElementToBeVisible(ChemicalMineralsUI.verifyRubberMaterial, 20);
				String actualData = helper.getText(ChemicalMineralsUI.verifyRubberMaterial);
				String expectedData = " Rubber Materials ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the RubberMaterial Fail");
				test.log(Status.FAIL, "Verify the RubberMaterial Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("RubberMaterial");
				test.addScreenCaptureFromPath(screenshotPath, "RubberMaterial");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Rubber Materials link Fail");
			test.log(Status.FAIL, "Click on Rubber Materials link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("RubberMaterials");
			test.addScreenCaptureFromPath(screenshotPath, "RubberMaterials");
		}
	}

	public void clickTheFirstProduct(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(ChemicalMineralsUI.firstProduct, 30);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,400)");
			helper.clickOnElement(ChemicalMineralsUI.firstProduct);
			helper.switchToNewWindow();
			// Verify firstProduct Service
			try {
				helper.waitForElementToBeVisible(ChemicalMineralsUI.verifyRubberMaterial, 20);
				String actualData = helper.getText(ChemicalMineralsUI.verifyRubberMaterial);
				String expectedData = " Rubber Materials ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the RubberMaterial Fail");
				test.log(Status.FAIL, "Verify the RubberMaterial Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("RubberMaterial");
				test.addScreenCaptureFromPath(screenshotPath, "RubberMaterial");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on First Product Fail");
			test.log(Status.FAIL, "Click on First Product link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("FirstProduct");
			test.addScreenCaptureFromPath(screenshotPath, "FirstProduct");
		}
	}

	public void addInquaryScroll(ExtentTest test) {
		// Scroll to Add Inquiry under Product.
		try {
			helper.waitForElementToBeVisible(ChemicalMineralsUI.addInquiry, 20);
//			helper.javascriptScroll(ChemicalMineralsUI.addInquiry);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,800)");

			// Verify firstProduct Service
			try {
				helper.waitForElementToBeVisible(ChemicalMineralsUI.addInquiry, 20);
				String actualData = helper.getText(ChemicalMineralsUI.addInquiry);
				String expectedData = "Add Inquiry Basket to Compare ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the RubberMaterial Fail");
				test.log(Status.FAIL, "Verify the RubberMaterial Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("RubberMaterial");
				test.addScreenCaptureFromPath(screenshotPath, "RubberMaterial");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Scroll to Add Inquiry Fail");
			test.log(Status.FAIL, "Scroll to Add Inquiry Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("AddInquiry");
			test.addScreenCaptureFromPath(screenshotPath, "AddInquiry");
		}
	}

	// click Add Inquary link under the product
	public void addInquaryProduct(ExtentTest test) {
		// Click on Add Inquiry under Product.
		try {
			helper.waitForElementToBeVisible(ChemicalMineralsUI.addInquiry, 20);
			helper.clickOnElement(ChemicalMineralsUI.addInquiry);
			// Verify firstProduct Service
			try {
				helper.waitForElementToBeVisible(ChemicalMineralsUI.addInquiry, 20);
				String actualData = helper.getText(ChemicalMineralsUI.addInquiry);
				String expectedData = "Add Inquiry Basket to Compare ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the RubberMaterial Fail");
				test.log(Status.FAIL, "Verify the RubberMaterial Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("RubberMaterial");
				test.addScreenCaptureFromPath(screenshotPath, "RubberMaterial");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Add Inquiry Fail");
			test.log(Status.FAIL, "Click on Add Inquiry Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("AddInquiry");
			test.addScreenCaptureFromPath(screenshotPath, "AddInquiry");
		}
	}

	// Click the Add inquary cart
	public void addInquaryCart(ExtentTest test) {
		// Click on Add Inquiry under Product.
		try {
			helper.waitForElementToBeVisible(ChemicalMineralsUI.inquiryBasket, 20);
			helper.clickOnElement(ChemicalMineralsUI.inquiryBasket);
			// Verify firstProduct Service
			try {
				helper.waitForElementToBeVisible(ChemicalMineralsUI.product, 20);
				String actualData = helper.getText(ChemicalMineralsUI.product);
				String expectedData = "Products";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the RubberMaterial Fail");
				test.log(Status.FAIL, "Verify the RubberMaterial Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("RubberMaterial");
				test.addScreenCaptureFromPath(screenshotPath, "RubberMaterial");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Add Inquiry Fail");
			test.log(Status.FAIL, "Click on Add Inquiry Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("AddInquiry");
			test.addScreenCaptureFromPath(screenshotPath, "AddInquiry");
		}
	}

	
	/*---------------Testcase-12---------------*/
	public void diamondMembers(ExtentTest test) {
		clickOnMoreCategories(test);
		clickChemicalAndMinerals(test);
		clickSteelProduct(test);
		scrollToMemberType(test);
		clickDiamondMember(test);

	}

	// Click the steel product
	public void clickSteelProduct(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.steelProduct, 20);
			helper.clickOnElement(MoreCategoriesUI.steelProduct);
			helper.switchToNewWindow();
			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifySteelProduct, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifySteelProduct);
				String expectedData = " Steel & Products ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Scroll to Member Type
	public void scrollToMemberType(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.memberType, 20);
			helper.javascriptScroll(MoreCategoriesUI.memberType);
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.memberType, 20);
				String actualData = helper.getText(MoreCategoriesUI.memberType);
				String expectedData = "Member Type";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the steel product
	public void clickDiamondMember(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.diamondMember, 20);
			helper.clickOnElement(MoreCategoriesUI.diamondMember);

			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyDiamond, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyDiamond);
				String expectedData = "Diamond Member";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	/*---------------Testcase-13---------------*/
	public void compaireProduct(ExtentTest test) {
		clickOnMoreCategories(test);
		clickHomeAndSecurity(test);
		clickOnSofa(test);
		clickFirstProduct(test);
		scrollFirstProductAddInquary(test);
		clickFirstProductInFindsimilar(test);
		scrollFirstProductAddInquary(test);

	}

	// Click the Home and Security
	public void clickHomeAndSecurity(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.homeSecurity, 20);
			helper.clickOnElement(MoreCategoriesUI.homeSecurity);

			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyHomeSecurity, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyHomeSecurity);
				String expectedData = "Home & Security";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the Sofa
	public void clickOnSofa(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.sofa, 20);
			helper.clickOnElement(MoreCategoriesUI.sofa);
			helper.switchToNewWindow();
			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifySofa, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifySofa);
				String expectedData = " Sofa ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the FirstProduct
	public void clickFirstProduct(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.firstProduct, 20);
			helper.clickOnElement(MoreCategoriesUI.firstProduct);
			helper.switchToNewWindow();
			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.verifyProductDetails, 20);
				String actualData = helper.getText(MoreCategoriesUI.verifyProductDetails);
				String expectedData = "Product Details";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the Scroll & click FirstProduct add inquary
	public void scrollFirstProductAddInquary(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(MoreCategoriesUI.addInquary, 20);
			helper.javascriptScroll(MoreCategoriesUI.addInquary);
			helper.clickOnElement(MoreCategoriesUI.addInquary);

			// verifySteelProduct Service
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.addInquary, 20);
				String actualData = helper.getText(MoreCategoriesUI.addInquary);
				String expectedData = "Add Inquiry Basket to Compare ";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}
	
	// Click the Find similar product
		public void clickFirstProductInFindsimilar(ExtentTest test) {
			try {
				helper.waitForElementToBeVisible(MoreCategoriesUI.findSimilar, 20);
				helper.javascriptScroll(MoreCategoriesUI.findSimilar);
				helper.clickOnElement(MoreCategoriesUI.clickFirstProduct);
				helper.switchToNewWindow();
				// verifySteelProduct Service
				try {
					helper.waitForElementToBeVisible(MoreCategoriesUI.clickFirstProduct, 20);
					String actualData = helper.getText(MoreCategoriesUI.clickFirstProduct);
					String expectedData = "Product Details";
					helper.softAsserting(actualData, expectedData);
					System.out.println(actualData);
					LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
					test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
				} catch (Exception e) {
					LoggerGeneretor.error("Verify the Product List Fail");
					test.log(Status.FAIL, "Verify the Product List Fail");
					String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
					test.addScreenCaptureFromPath(screenshotPath, "ProductList");
				}

			} catch (Exception e) {
				LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
				test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
				test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
			}
		}


}
