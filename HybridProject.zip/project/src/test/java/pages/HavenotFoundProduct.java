package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.HavenotFoundProductUI;
import uistore.HavenotFoundProductUI;
import utils.CaptureScreenshot;
import utils.DriverHelper;
import utils.LoggerGeneretor;
import utils.ReadFromExcel;
import utils.ReporterMaker;

public class HavenotFoundProduct {
	WebDriver driver;
	DriverHelper helper;

	public HavenotFoundProduct(WebDriver driver) {
		this.driver = driver;
		helper = new DriverHelper(driver);
	}

	/*---------------Testcase-11---------------*/

	public void souricingRequest(ExtentTest test) {
		clickOnMoreCategories(test);
		scrollToHavenotFound(test);
		clickSourceNow(test);
		clickInputField(test);

	}

	public void clickOnMoreCategories(ExtentTest test) {
		// Click the More Categories link
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.moreCategories, 20);
			helper.clickOnElement(HavenotFoundProductUI.moreCategories);
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.chinaProductsDirectory, 20);
				String actualData = helper.getText(HavenotFoundProductUI.chinaProductsDirectory);
				String expectedData = "China Products Directory";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	public void scrollToHavenotFound(ExtentTest test) {
		// Click the Chemicals & Minerals link
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.haveNotFound, 20);
			helper.javascriptScroll(HavenotFoundProductUI.haveNotFound);
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.haveNotFound, 20);
				String actualData = helper.getText(HavenotFoundProductUI.haveNotFound);
				String expectedData = "Haven’t found what you want?";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the Source Now Button
	public void clickSourceNow(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.sourcingRequest, 20);
			helper.clickOnElement(HavenotFoundProductUI.sourcingRequest);
			helper.switchToNewWindow();
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.verifySourcing, 20);
				String actualData = helper.getText(HavenotFoundProductUI.verifySourcing);
				String expectedData = "Tell suppliers what you need";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	// Click the input field
	public void clickInputField(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.productName, 20);
			helper.clickOnElement(HavenotFoundProductUI.productName);
			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(6, 4);
			helper.sendKeys(HavenotFoundProductUI.productName, excelData);
			System.out.println(excelData);
			// Verify Secured Trading Service
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.categories, 20);
				String actualData = helper.getText(HavenotFoundProductUI.categories);
				String expectedData = "Packaging & Printing»Package & Conveyance»Packaging Bags";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Click and Verify the input data " + actualData + " is Pass");
				test.log(Status.PASS, "Click and Verify the input data " + actualData + " is Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Verify the Product List Fail");
				test.log(Status.FAIL, "Verify the Product List Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("ProductList");
				test.addScreenCaptureFromPath(screenshotPath, "ProductList");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on Chemical And Minerals link Fail");
			test.log(Status.FAIL, "Click on Chemical And Minerals link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("ChemicalAndMinerals");
			test.addScreenCaptureFromPath(screenshotPath, "ChemicalAndMinerals");
		}
	}

	/*---------------Testcase-14---------------*/

	public void subscribeProductAlertForLaptop(ExtentTest test) {
		clickOnMoreCategories(test);
		scrollToHavenotFound(test);
		clickOnSubscribeProduct(test);
		clickOnInputField(test);
		clickOnConfirmButton(test);
		/*
		int row = 7;
		int col =4;
		for(int i=1;i<=3;i++) {
			clickOnInputField(test,row,col);
			row++;
		}
		*/
		

	}

	// Click the Subscribe Now
	public void clickOnSubscribeProduct(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.subscribeNow, 20);
			helper.clickOnElement(HavenotFoundProductUI.subscribeNow);
			helper.switchToNewWindow();
			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.subscribeProdAlert, 20);
				String actualData = helper.getText(HavenotFoundProductUI.subscribeProdAlert);
				String expectedData = "Subscribe to Product Alert";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the input field and search
//	public void clickOnInputField(ExtentTest test,int row, int col) {
		public void clickOnInputField(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.inputField, 20);
			helper.clickOnElement(HavenotFoundProductUI.inputField);
//			System.out.println(row);
			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(7, 4);
			helper.sendKeys(HavenotFoundProductUI.inputField, excelData);
			System.out.println(excelData);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.inputField, 20);
				String actualData = helper.getText(HavenotFoundProductUI.inputField);
				String expectedData = "Laptop";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the clickOnConfirmButton
	public void clickOnConfirmButton(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.confirm, 20);
			helper.clickOnElement(HavenotFoundProductUI.confirm);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.product, 20);
				String actualData = helper.getText(HavenotFoundProductUI.product);
				String expectedData = "Computer Products >> Computer Products";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}
	/*---------------Testcase-15---------------*/

	public void subscribeProductAlertForInvalidInput(ExtentTest test) {
		clickOnMoreCategories(test);
		scrollToHavenotFound(test);
		clickOnSubscribeProduct(test);
		clickOnInputFieldPassInvalidInput(test);
		clickOnConfirmButtonWithInvalidInput(test);

	}

	// Click the input field and search
	public void clickOnInputFieldPassInvalidInput(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.inputField, 20);
			helper.clickOnElement(HavenotFoundProductUI.inputField);

			// Send the data from excel
			String excelpath = System.getProperty("user.dir") + "/testdata/data.xlsx";
			String excelData = ReadFromExcel.readdata(8, 4);
			helper.sendKeys(HavenotFoundProductUI.inputField, excelData);
			System.out.println(excelData);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.inputField, 20);
				String actualData = helper.getText(HavenotFoundProductUI.inputField);
				String expectedData = "iiiiiiinnnnnnnnnvvvvvaaaaaaalllllllliiiiiiiidddddd";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
				String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
				test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the clickOnConfirmButton
	public void clickOnConfirmButtonWithInvalidInput(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.confirm, 20);
			helper.clickOnElement(HavenotFoundProductUI.confirm);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.invalidProduct, 20);
				String actualData = helper.getText(HavenotFoundProductUI.invalidProduct);
				String expectedData = "No result. Please check the keyword you entered.";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}
	/*---------------Testcase-16---------------*/

	public void subscribeProductWithValidInput(ExtentTest test) {
		clickOnMoreCategories(test);
		scrollToHavenotFound(test);
		clickOnSubscribeProduct(test);
		clickOnInputField(test);
		clickOnConfirmButton(test);
		clickOnSubscribeButtonToSubscribe(test);

	}

	// Click the subscribe button
	public void clickOnSubscribeButtonToSubscribe(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(HavenotFoundProductUI.clickSubscribebutton, 20);
			helper.javascriptScroll(HavenotFoundProductUI.clickSubscribebutton);
			helper.clickOnElement(HavenotFoundProductUI.clickSubscribebutton);

			// Verify the Subscribe to Product Alert title is present.
			try {
				helper.waitForElementToBeVisible(HavenotFoundProductUI.verifySignIn, 20);
				String actualData = helper.getText(HavenotFoundProductUI.verifySignIn);
				String expectedData = "Sign in with";
				helper.softAsserting(actualData, expectedData);
				System.out.println(actualData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}
			CaptureScreenshot.captureScreenShot("Alert");

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

}
