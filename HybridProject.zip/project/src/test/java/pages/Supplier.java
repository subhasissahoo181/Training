package pages;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import uistore.MoreCategoriesUI;
import uistore.SupplierUI;
import utils.DriverHelper;
import utils.LoggerGeneretor;
import utils.ReporterMaker;

public class Supplier {
	WebDriver driver;
	DriverHelper helper;

	public Supplier(WebDriver driver) {
		this.driver = driver;
		helper = new DriverHelper(driver);
	}

	/*------------------------------------TestCase-9------------------------------------*/
	/*
	 * Method Name:- isShoesDetails() Author Name:- SubhasisSahoo(10820896) Short
	 * Description Of Method:- Open the application through the website URL and
	 * Verify that the user can browse various product categories. Return Type:-
	 * Void Parameter LIst:- NotApplicable
	 */
	public void supplierDetails(ExtentTest test) {
		clickOnMoreCategories(test);
		clickOnConsumerGoods(test);
		clickOnTvParts(test);
		supplierList(test);

	}
	// Click the More Categories link

	public void clickOnMoreCategories(ExtentTest test) {
		// Click the More Categories link
		try {
			helper.waitForElementToBeVisible(SupplierUI.moreCategories, 20);
			helper.clickOnElement(SupplierUI.moreCategories);
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(SupplierUI.chinaProductsDirectory, 20);
				String actualData = helper.getText(SupplierUI.chinaProductsDirectory);
				String expectedData = "China Products Directory";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click On ConsumerGoods link
	public void clickOnConsumerGoods(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(SupplierUI.consumerGoods, 20);
			helper.clickOnElement(SupplierUI.consumerGoods);
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(SupplierUI.verifyConsumerGoods, 20);
				String actualData = helper.getText(SupplierUI.verifyConsumerGoods);
				String expectedData = "Consumer Goods & Electronics";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the Tv & Parts link
	public void clickOnTvParts(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(SupplierUI.tvParts, 20);
			helper.clickOnElement(SupplierUI.tvParts);
			helper.switchToNewWindow();
			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(SupplierUI.verifyTvParts, 20);
				String actualData = helper.getText(SupplierUI.verifyTvParts);
				String expectedData = " TV & Parts ";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the supplier List link
	public void supplierList(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(SupplierUI.supplierList, 20);
			helper.clickOnElement(SupplierUI.supplierList);

			// Verify the China Products title is present.
			try {
				helper.waitForElementToBeVisible(SupplierUI.verifyTvPartsSupplierList, 20);
				String actualData = helper.getText(SupplierUI.verifyTvPartsSupplierList);
				String expectedData = " TV & Parts ";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	/*--------------------------------Testcase-10-----------------------------*/
	public void supplyOpticalFiber(ExtentTest test) {
		clickOnMoreCategories(test);
		clickOnConsumerGoods(test);
		clickOnFiberOptics(test);
		supplierList(test);
		scrollVerifyOpticalfiber(test);

	}

	// Click the fiberOptics List link
	public void clickOnFiberOptics(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(SupplierUI.fiberOptics, 20);
			helper.clickOnElement(SupplierUI.fiberOptics);
			helper.switchToNewWindow();
			// Verify the fiberOptics title is present.
			try {
				helper.waitForElementToBeVisible(SupplierUI.verifyFiberOptics, 20);
				String actualData = helper.getText(SupplierUI.verifyFiberOptics);
				String expectedData = " Fiber Optic Equipment ";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

	// Click the scroll and verify fiberOptics List link
	public void scrollVerifyOpticalfiber(ExtentTest test) {
		try {
			helper.waitForElementToBeVisible(SupplierUI.relatedCategories, 20);
			helper.javascriptScroll(SupplierUI.relatedCategories);
			// Verify the fiberOptics title is present.
			try {
				helper.waitForElementToBeVisible(SupplierUI.verifyOpticalFiber, 20);
				String actualData = helper.getText(SupplierUI.verifyOpticalFiber);
				String expectedData = "Optical Fiber";
				helper.softAsserting(actualData, expectedData);
				LoggerGeneretor.info("Verify the China Products title is " + actualData + " Pass");
				test.log(Status.PASS, "Verify the China Products title is " + actualData + " Pass");
			} catch (Exception e) {
				LoggerGeneretor.error("Click and Verify the China Products title is  Fail");
				test.log(Status.FAIL, "Click and Verify the China Products title is  Fail");
				String screenshotPath = ReporterMaker.captureScreenShot("VerifyChinaProducts");
				test.addScreenCaptureFromPath(screenshotPath, "VerifyChinaProducts");
			}

		} catch (Exception e) {
			LoggerGeneretor.error("Click on More Categories link Fail");
			test.log(Status.FAIL, "Click on More Categories link Fail");
			String screenshotPath = ReporterMaker.captureScreenShot("MoreCategories");
			test.addScreenCaptureFromPath(screenshotPath, "MoreCategoriesSection");
		}

	}

}
