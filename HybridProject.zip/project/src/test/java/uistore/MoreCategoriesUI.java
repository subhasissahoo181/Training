package uistore;

import org.openqa.selenium.By;

public class MoreCategoriesUI {
	// TestCase-1	
	public static By moreCategories = By.xpath("//span[@class='fl cate-name']");
	public static By chinaProductsDirectory = By.xpath("//h1[text()='China Products Directory']");	
	public static By apparelandLight = By.xpath("(//a[@class='J-tab-anchor tab-anchor'])[4]");
	public static By verifyApparelandLight = By.xpath("//h2[text()='Apparel & Light Industry']");	
	public static By clickApparelandAccessories = By.xpath("//a[text()='Apparel & Accessories']");
	public static By verifyApparelandAccessories = By.xpath("//h1[text()='Apparel & Accessories ']");
	
	//TestCase-12
//	public static By steelProduct = By.xpath("//a[@href='https://www.made-in-china.com/Metallurgy-Mineral-Energy-Catalog/Steel-Products.html?pv_id=1id67n3tu8a7&faw_id=null']");
	public static By steelProduct = By.xpath("//a[text()='Steel & Products']");
	public static By verifySteelProduct = By.xpath("//h1[text()=' Steel & Products ']");
	public static By memberType = By.xpath("(//div[@class='filter-item-text'])[3]");
	public static By diamondMember = By.xpath("(//a[@class='member-check'])[1]/span");
	public static By verifyDiamond = By.xpath("(//span[text()='Diamond Member'])[1]");
	//TestCase-13
	public static By homeSecurity = By.xpath("(//a[@class='J-tab-anchor tab-anchor'])[2]");
	public static By verifyHomeSecurity = By.xpath("//h2[text()='Home & Security']");
	public static By sofa = By.xpath("(//a[@class='item-anchor'])[40]");
	public static By verifySofa = By.xpath("//h1[@class='product_word']");
//	public static By firstProduct = By.xpath("(//div[@class='img-thumb-inner'])[2]/img");
	public static By firstProduct = By.xpath("(//div[@class='list-img-wrap'])[1]");
	public static By verifyProductDetails = By.xpath("//span[text()='Product Details']");
	public static By addInquary = By.xpath("//span[@class='J-add-to-basket NakpMejuXRVG add-to-basket']/a");
	public static By findSimilar = By.xpath("//div[text()='Find Similar Products']");
	public static By clickFirstProduct = By.xpath("(//div[@class='sr-similar-product-item J-similar-product-item'])[1]");
	public static By inquaryHover = By.xpath("//div[@id='J-inquiryControl']");
	public static By verifyProducrInCart = By.xpath("//ul[@class='in-basket-tab']/li[1]");
	public static By selectALl = By.xpath("//div[@class='input-checkbox']/label/span");
	public static By compaire = By.xpath("//a[@class='btn btn-compare J-compare']");
	public static By verifyComPaire = By.xpath("//div[text()=' Compare Products ']");
	
	//Testcase-17
	public static By shoes = By.cssSelector(".item-anchor[href='//www.made-in-china.com/Apparel-Accessories-Catalog/Shoes.html']");
	public static By verifyProductCategories = By.xpath("//h1[@class='product_word']");
	public static By startOrder = By.cssSelector("a.trading-bnr");
	public static By verifySecureTrading = By.cssSelector("a.m-channel-name-content");
	
	//	Testcase-18
	public static By childrenApperal = By.cssSelector("a.item-anchor[href='//www.made-in-china.com/Apparel-Accessories-Catalog/Children-s-Apparel.html']");
	public static By age = By.xpath("//div[@id='J-category']/dl[3]/dt/h3");
	public static By ageRange = By.xpath("//a[@href='/multi-search/Children-s-Apparel-Catalog/F0--PV_1104110000_308154_1130962504/1.html']");
	public static By verifyAge = By.className("filter-list-item-text");
	
//	TestCase-19
	public static By easySourcing = By.xpath("//div[@class='sourcing-title']");
	public static By productNameInput = By.xpath("//input[@placeholder='Product Name or Keywords']");
	public static By postRequestNow = By.xpath("//button[text()='Post Your Request Now']");
	public static By verifyInputValue = By.xpath("//input[@id='subjectId']");
	
//	TestCase-20
	public static By tShirt = By.xpath("//a[text()='T-Shirt']");
	public static By verifyTshirt = By.xpath("//h1[@class='product_word']");
	public static By poloTshirt = By.xpath("(//a[text()='Polo Shirt'])[2]");
	public static By productDetails = By.xpath("//span[text()='Product Details']");
	public static By modelNumber = By.xpath("//div[text()='Model NO.']");
	
	//TestCase-21
	public static By transpotation = By.xpath("(//a[@class='J-tab-anchor tab-anchor'])[3]");
	public static By verifyTransport = By.xpath("//a[text()='Transportation & Sporting Goods']");
	public static By  bike = By.xpath("//a[text()='Bike']");
	public static By verifyBike = By.xpath("//h1[@class='product_word']");
	public static By supplierList = By.xpath("//a[@href='//www.made-in-china.com/manufacturers-directory/item3/Bicycle-Bicycle-Parts-1.html']");
	public static By provinceRegion = By.xpath("//h3[text()='Province & Region']");
	public static By gungdong = By.xpath("//a[text()='Guangdong ']");
	public static By verifyGungdong = By.xpath("//span[@class='refine-selected']");
	
	
}

