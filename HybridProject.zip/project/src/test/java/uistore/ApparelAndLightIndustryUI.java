package uistore;

import org.openqa.selenium.By;

public class ApparelAndLightIndustryUI {
	public static By moreCategories = By.xpath("//span[@class='fl cate-name']");
	public static By apparelAndLight = By.xpath("(//a[@class='J-tab-anchor tab-anchor'])[4]");
	public static By fashionAccessories = By.xpath("(//li[@class='thd-classify-item'])[73]");
	public static By  firstProduct = By.xpath("(//h2[@class='product-name'])[1]");
	public static By verifyFashionAccessories = By.xpath("//a[text()='Fashion Accessories']");

}
