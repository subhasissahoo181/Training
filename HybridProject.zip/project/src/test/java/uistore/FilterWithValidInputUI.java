package uistore;

import org.openqa.selenium.By;

public class FilterWithValidInputUI {
	// TestCase-2	
		
		public static By hotSearches = By.xpath("//div[text()='Hot Searches']");
		public static By clickFirstButton = By.xpath("(//a[@class='hot-item btn'])[1]");
//		public static By verifyProductList = By.xpath("//li[@class='selected']/a");
		public static By verifyProductList = By.xpath("//h1[@class='product_word']");
//		public static By securedTrading = By.xpath("//a[@href='//trading.made-in-china.com/deals/multi-search/LED/F1/1.html']");
//		public static By securedTrading = By.xpath("//a[text()='Secured Trading']");
		public static By securedTrading = By.xpath("(//ul[@class='tab']/li)[3]/a");
		public static By verifysecuredTrading = By.xpath("//a[text()='Secured Trading Service']");
		public static By minOrder = By.xpath("//input[@id='minorderinput']");
		public static By verifyMinOrder = By.xpath("//label[text()='Min Order:']");
		public static By minOrderOk = By.xpath("//button[@id='minorderbtn']");
		public static By minPrice = By.xpath("//input[@class='J-minPrice-input']");
		public static By maxPrice = By.xpath("//input[@class='J-maxPrice-input']");
		public static By verifyPrice = By.xpath("//label[text()='Price:']");
		public static By priceOK = By.xpath("//button[@class='btn btn-small J-price-submit']");
		public static By verifyProductFound = By.xpath("//div[@class='list-key list-key-new']");
}
