package runner;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import utils.Base;

public class TestRunner extends Base {
    
    ExtentReports reports;
    ExtentSparkReporter reporter;
    ExtentTest test;
    Logger log = LogManager.getLogger(TestRunner.class);
    
    @BeforeTest
    public void isReport() {
        String filePath = System.getProperty("user.dir") + "/reports/report.html";
        reporter = new ExtentSparkReporter(filePath);
        reports = new ExtentReports();
        reports.attachReporter(reporter);
    } 

    @BeforeMethod
    public void openMybrowser() {
        openBrowser();
    }

    @Test
    public void test0() throws InterruptedException, IOException {
        log.info("Test1 started..");
        WebElement holiday = driver.findElement(By.xpath("//span[text()='Holidays']"));
        holiday.click();

        WebElement ayurvedic = driver.findElement(By.xpath("//span[text()='Ayurveda']"));
        ayurvedic.click();

        driver.navigate().back();
        driver.navigate().back();

        WebElement visa = driver.findElement(By.xpath("//span[text()='Visa']"));
        visa.click();

        WebElement sigin = driver.findElement(By.xpath("//span[text()='Login or Signup']"));
        Actions action = new Actions(driver);
        action.moveToElement(sigin).build().perform();

        WebElement customer = driver.findElement(By.xpath("//span[text()='Customer Login']"));
        customer.click();

        WebElement data = driver.findElement(By.xpath("//input[@id='txtEmail']"));
        Thread.sleep(3000);
        data.sendKeys("demo@gmail.com");

        WebElement continues = driver.findElement(By.xpath("//input[@id='shwotp']"));
        continues.click();

        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);
        File dest = new File(System.getProperty("user.dir") + "/screenshots/screenshot.png");
        FileUtils.copyFile(src, dest);

        Thread.sleep(3000);
    }

    @Test
    public void test1() throws InterruptedException, IOException {
        WebElement element = driver.findElement(By.xpath("//span[text()='More']"));
        Actions action = new Actions(driver);
        action.moveToElement(element).build().perform();
        Thread.sleep(3000);

        driver.findElement(By.xpath("//span[text()='EasyDarshan']")).click();
        String NewTab = driver.getWindowHandle();
        Set<String> handles = driver.getWindowHandles();
        for (String handle : handles) {
            if (!NewTab.equals(handle)) {
                driver.switchTo().window(handle);
            }
        }
        Thread.sleep(3000);
        driver.findElement(By.id("txtDesCity")).sendKeys("Tirupati");
        Thread.sleep(3000);
        driver.findElement(By.xpath("//p[text()='Tirupati']")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//button[text()='Search']")).click();
        Thread.sleep(3000);
    }

    @AfterMethod
    public void teardown(ITestResult result) {
        if (result.getStatus() == ITestResult.SUCCESS) {
            test.log(Status.PASS, result.getName());
        } else if (result.getStatus() == ITestResult.FAILURE) {
            test.log(Status.FAIL, result.getName() + result.getThrowable());
            // Uncomment and correct the following line if you want to take a screenshot on failure
            // String base64Screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
        }

        driver.quit();
    }

    @AfterTest
    public void generateFlushReport() {
        reports.flush();
    }
}
