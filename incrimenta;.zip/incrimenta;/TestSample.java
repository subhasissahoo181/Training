package runner;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.Base;


public class TestSample extends Base{
    Logger log = LogManager.getLogger(TestSample.class);
    @Test
    public void test0() throws InterruptedException,IOException{
        log.info("Test1 started..");
        WebElement holiday = driver.findElement(By.xpath("//span[text()='Holidays']"));
        holiday.click();

        WebElement ayurvedic =  driver.findElement(By.xpath("//span[text()='Ayurveda']"));
        ayurvedic.click();

        driver.navigate().back();
        driver.navigate().back();

        WebElement visa =  driver.findElement(By.xpath("//span[text()='Visa']"));
        visa.click();

        WebElement sigin = driver.findElement(By.xpath("//span[text()='Login or Signup']"));
        Actions action = new Actions(driver);
        action.moveToElement(sigin).build().perform();

        WebElement customer = driver.findElement(By.xpath("//span[text()='Customer Login']"));
        customer.click();

        WebElement data = driver.findElement(By.xpath("//input[@id='txtEmail']"));
        Thread.sleep(3000);
        data.sendKeys("demo@gmail.com");

        WebElement continues = driver.findElement(By.xpath("//input[@id='shwotp']"));
        continues.click();

        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);
        File dest = new File(System.getProperty("user.dir")+"/screenshots/screenshot.png");
        FileUtils.copyFile(src, dest);

   }
    
     
    @BeforeMethod
    public void browser(){
        openBrowser();
    }
    @AfterMethod
    public void end() throws InterruptedException{
        Thread.sleep(5000);
        driver.quit();
    }
    
}